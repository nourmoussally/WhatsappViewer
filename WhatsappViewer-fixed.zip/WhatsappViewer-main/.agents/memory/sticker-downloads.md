---
name: Sticker downloads
description: Sticker download behavior and the limitation of msgstore CDN links.
---

The msgstore database stores sticker metadata, a media key, and often a temporary CDN direct path, but not the sticker bytes. Sticker downloads can decrypt a valid CDN response locally; expired CDN links require importing the device's WhatsApp Stickers folder and matching files by basename.

**Why:** Old WhatsApp backups commonly contain CDN URLs that return 403 even though the original `.webp` files still exist on the device.

**How to apply:** Offer both paths: use the stored link/key when valid, and use a locally selected `.webp` sticker folder as the reliable fallback; use the local sticker file as the preview source too.