---
name: Message reactions (emoji)
description: Reactions live in message_add_on/message_add_on_reaction (type=56), not on the message row — fetched per-chat and attached to Message.reactions.
---

Emoji reactions (❤️👍😂...) are NOT part of the `message` table. Confirmed against a real production `msgstore.db`: they live in `message_add_on` (columns include `chat_row_id`, `parent_message_row_id` -> `message._id`, `from_me`, `sender_jid_row_id`, `message_add_on_type`) joined to `message_add_on_reaction` (`message_add_on_row_id`, `reaction` text) on `message_add_on._id = message_add_on_reaction.message_add_on_row_id`.

- `message_add_on_type = 56` is reactions (other observed types: 74, 56, 67, 79 — only 56 has matching rows in `message_add_on_reaction`).
- Some `reaction` values are NULL/empty string — these are *removed* reactions and must be filtered out (`WHERE mar.reaction IS NOT NULL AND mar.reaction != ''`).
- A message can have reactions from multiple different people with different emoji — group by emoji for display, don't assume one reaction per message.
- No duplicate (same sender, same message) rows were observed, so no "latest wins" dedup was needed.
- Reactor identity for group chats resolves through `sender_jid_row_id` exactly like [[group-sender-identity]] (same `jid`/`jid_map` LID-to-phone-number join) — `from_me=1` needs no resolution, and `sender_jid_row_id=-1` in a 1:1 chat means "the chat's other contact" (no lookup needed, already known from the conversation itself).

**How to apply:** Fetch all of a chat's reactions in a single batched query (keyed by `chat_row_id`, not per-message) after loading its messages, then attach to each `Message.reactions` by `parent_message_row_id`. Group by emoji in the UI layer for display (count + "who reacted" tooltip), not in the query.
