---
name: Shared contact (vCard) messages
description: Contact-share messages (waType 4) showed "No filename stored" because their data lives in message_vcard, not message_media.
---

Messages sharing a contact card (`media_wa_type`/`message_type` = 4, labeled "Contact") have no associated file — their `message_media` row (if any) has no name or caption, which fell through to the generic "No filename stored" state. The actual contact data is raw vCard text (`BEGIN:VCARD ... FN:Name ... TEL...:+123 ... END:VCARD`) in a separate `message_vcard` table, joined on `message_row_id`, in a `vcard` column.

**How to apply:** LEFT JOIN `message_vcard` alongside the existing call/location joins, parse the `FN:` (fall back to `N:`) and `TEL:` lines out of the raw vCard text, and render the parsed name/phone in place of the filename for contact messages instead of the "No filename stored" fallback.
