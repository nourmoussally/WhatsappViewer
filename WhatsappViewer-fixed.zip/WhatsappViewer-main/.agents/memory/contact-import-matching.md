---
name: Contact import matching
description: Contact-file support and phone matching behavior for the WhatsApp viewer.
---

Contacts are imported locally from VCF/vCard or CSV files. Matching uses normalized international digits, removing formatting characters and converting a leading `00` to the same canonical form as a `+` number. Imported names are display metadata only; the WhatsApp phone number remains visible.

VCF names may be encoded as UTF-8 quoted-printable text (`=D8=A7...` for Arabic); decode that property encoding before displaying the imported name.

**Why:** Contact exports vary in file format and phone formatting, while the backup stores phone numbers in a canonical international form.

**How to apply:** Keep contact import client-side, accept both common formats, match on normalized digits, and show the original number alongside the imported name.