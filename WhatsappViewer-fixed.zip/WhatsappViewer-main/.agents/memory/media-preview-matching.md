---
name: WhatsApp media preview matching
description: Local WhatsApp media files need filename and extension based matching; message_media has two differently-reliable name columns.
---

Media preview must not depend only on MIME metadata. WhatsApp exports may have UUID filenames and browsers may report an empty MIME type; infer image, video, or audio from the filename extension and normalize decoded path basenames before matching.

**Why:** A valid local image can otherwise appear as metadata-only even when its file was selected.

**How to apply:** Match decoded basenames from both database paths and selected folder files, then use MIME, extension, and WhatsApp media type as fallbacks for rendering.

**`file_path` vs `media_name` (critical, confirmed against a real production msgstore.db):** `message_media.file_path` holds the real local filename WhatsApp saved the file under (e.g. `Media/WhatsApp Voice Notes/202401/PTT-20241230-WA0031.opus`, `Media/WhatsApp Stickers/STK-20241230-WA0043.webp`). `message_media.media_name` is frequently an *internal hash-style identifier* that looks like a filename but is unrelated to the file on disk (e.g. `3c9ed633ff7e4e5caf5b5bda25a0390d.opus`, `nMqFKOWAuFjSxxWM3qyzd19awyFdKy830n9UDVXhwy4=.webp`, or a UUID). Preferring `media_name` over `file_path` (an earlier version of this code did) shows the wrong name for the vast majority of received stickers/voice notes/video and makes local-file matching fail even though the real file is present in the selected folder under the `file_path`-derived name.

Occasionally `file_path`'s basename is missing an extension (ends with a bare `.`, e.g. `Media/WhatsApp Documents/Sent/DOC-20250104-WA0023.`) while `media_name` already has one and holds the original device filename (e.g. `IMG_20250104_015606_579.jpg`) — so the rule isn't "always file_path": pick whichever of the two candidate names already has a real extension (`file_path` first), only reconstruct an extension from `mime_type` as a last resort when neither does, and keep the non-chosen candidate as `media_alt_name` so local-file lookup can try it too if the primary name doesn't match anything in the selected folder.
