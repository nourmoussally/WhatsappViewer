---
name: Media that was never downloaded to the device
description: message_media rows with no file_path AND no media_name at all mean WhatsApp never saved a local copy — no filename fix can ever match these.
---

Some `message_media` rows have BOTH `file_path` and `media_name` NULL, with only server-side fields present (`direct_path`/`message_url`, `file_hash`, `media_job_uuid`). Confirmed against a real production `msgstore.db`: this is common for images (`message_type` 42) and some video/audio, and it means WhatsApp never saved a local copy of that media on the device at all (never downloaded, expired/auto-deleted, etc.) — it is NOT the same bug as [[media-preview-matching]] (wrong-but-real name stored). There is no real local filename to recover here, from this database or any other source.

The only name we can produce for these is synthesized from the CDN `direct_path` token (e.g. newer-style paths like `/o1/v/t62.../f2/m238/AQPy1uE4Kw...`, which — unlike the older `.enc`-suffixed paths — have no extension at all, so `mimeToExt` needs to be applied unconditionally, not just for the `.enc` case). This synthesized value is a WhatsApp server token, never a real filename, and can never match anything in a local Media folder.

**How to apply:** Track this case explicitly (`Message.media_never_downloaded`) rather than lumping it in with the generic "name unreliable" state, and show a distinct explanation in the UI ("WhatsApp never saved a local copy of this file") instead of displaying the meaningless CDN token as if it were a filename.
