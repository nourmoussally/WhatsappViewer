---
name: Group message sender identity
description: Show which participant sent each incoming group message using message.sender_phone, which dbService already resolves but the UI never rendered.
---

`getMessages` already resolves `message.sender_phone` for group chats (via `sender_jid_row_id` -> `jid`, with LID -> real-number mapping through `jid_map` reused from `getConversations`/[[whatsapp-lid-phone-mapping]]) and puts it on `Message.sender_phone`. It was previously computed but never displayed anywhere in the UI, so group messages showed with no indication of who sent them.

**How to apply:** In `ChatWindow`, for a group conversation (`conversation.subject` is set) and an incoming message (`!msg.from_me`), resolve a label — the saved contact name for `normalizePhone(sender_phone)` from the existing `contactMap`, falling back to the raw phone number, falling back to "Unknown participant" if `sender_phone` is null — and a per-sender color (hash the phone into a small fixed palette so the same person is consistent across the chat). Pass both into `MessageBubble`, which renders the label at the top of the bubble in that color, WhatsApp-style. Outgoing messages (`from_me`) never show a sender label.
