---
name: WhatsApp LID phone mapping
description: How modern WhatsApp msgstore databases expose phone numbers for LID chats.
---

Modern WhatsApp backups may store one-to-one chats with `jid.server = 'lid'`, so the digits in the LID JID are not a phone number. When present, `jid_map.lid_row_id` points to a second `jid` row whose `server = 's.whatsapp.net'`; that mapped `jid.user` is the real phone number. `lid_display_name.display_name` can be masked and must not be treated as the real number.

**Why:** Converting LID digits directly into a `+` phone number shows an internal identifier and can mislead the user.

**How to apply:** Resolve LID chats through `jid_map` first, use direct `s.whatsapp.net` JIDs for legacy records, and clearly label the number as unavailable when neither source exists.