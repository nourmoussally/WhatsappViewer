import { Message } from '../types';

const CDN_ORIGIN = 'https://mmg.whatsapp.net';
const STICKER_KEY_INFO = 'WhatsApp Image Keys';

const toBytes = (value: Uint8Array | number[] | ArrayBuffer): Uint8Array => {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  return new Uint8Array(value);
};

const toArrayBuffer = (value: Uint8Array): ArrayBuffer =>
  value.slice().buffer as ArrayBuffer;

const concatBytes = (...parts: Uint8Array[]): Uint8Array => {
  const result = new Uint8Array(parts.reduce((total, part) => total + part.length, 0));
  let offset = 0;
  parts.forEach((part) => {
    result.set(part, offset);
    offset += part.length;
  });
  return result;
};

const sameBytes = (a: Uint8Array, b: Uint8Array): boolean =>
  a.length === b.length && a.every((value, index) => value === b[index]);

const expandMediaKey = async (mediaKey: Uint8Array): Promise<Uint8Array> => {
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(mediaKey),
    { name: 'HKDF' },
    false,
    ['deriveBits'],
  );
  const expanded = await crypto.subtle.deriveBits(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new Uint8Array(32),
      info: new TextEncoder().encode(STICKER_KEY_INFO),
    },
    cryptoKey,
    112 * 8,
  );
  return new Uint8Array(expanded);
};

const decryptSticker = async (encryptedFile: ArrayBuffer, mediaKey: Uint8Array): Promise<Blob> => {
  const expanded = await expandMediaKey(mediaKey);
  const iv = expanded.slice(0, 16);
  const cipherKey = expanded.slice(16, 48);
  const macKey = expanded.slice(48, 80);
  const encrypted = new Uint8Array(encryptedFile);

  if (encrypted.length <= 10) {
    throw new Error('The downloaded sticker file is incomplete.');
  }

  const ciphertext = encrypted.slice(0, -10);
  const receivedMac = encrypted.slice(-10);
  const hmacKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(macKey),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const calculatedMac = new Uint8Array(await crypto.subtle.sign(
    'HMAC',
    hmacKey,
    toArrayBuffer(concatBytes(iv, ciphertext)),
  ));

  if (!sameBytes(receivedMac, calculatedMac.slice(0, 10))) {
    throw new Error('Sticker authentication failed. The CDN link may be expired.');
  }

  const aesKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(cipherKey),
    { name: 'AES-CBC' },
    false,
    ['decrypt'],
  );
  const plain = await crypto.subtle.decrypt(
    { name: 'AES-CBC', iv: toArrayBuffer(iv) },
    aesKey,
    toArrayBuffer(ciphertext),
  );
  return new Blob([plain], { type: 'image/webp' });
};

const getStickerUrl = (directPath: string): string =>
  directPath.startsWith('http') ? directPath : `${CDN_ORIGIN}${directPath}`;

const getDownloadName = (message: Message): string => {
  const name = message.media_name || `sticker-${message._id}.webp`;
  const cleanName = name.split(/[\\/]/).pop() || `sticker-${message._id}.webp`;
  return cleanName.toLowerCase().endsWith('.webp') ? cleanName : `${cleanName}.webp`;
};

const saveBlob = (blob: Blob, fileName: string) => {
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(objectUrl);
};

export const downloadSticker = async (message: Message, localFile?: File): Promise<void> => {
  if (localFile) {
    saveBlob(localFile, localFile.name);
    return;
  }

  if (!message.media_direct_path || !message.media_key) {
    throw new Error('This sticker has no downloadable link or key in the database.');
  }

  const response = await fetch(getStickerUrl(message.media_direct_path));
  if (!response.ok) {
    throw new Error(`WhatsApp CDN returned ${response.status}. Use a newer database backup.`);
  }

  const mediaKey = toBytes(message.media_key);
  const sticker = await decryptSticker(await response.arrayBuffer(), mediaKey);
  saveBlob(sticker, getDownloadName(message));
};