import { Conversation, Message } from '../types';

declare global {
  interface Window {
    initSqlJs: (config: any) => Promise<any>;
  }
}

let dbInstance: any = null;

// ── Init ─────────────────────────────────────────────────────────
export const initDatabase = async (buffer: ArrayBuffer): Promise<void> => {
  if (!window.initSqlJs) throw new Error("SQL.js not loaded");
  const SQL = await window.initSqlJs({
    locateFile: (f: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${f}`,
  });
  dbInstance = new SQL.Database(new Uint8Array(buffer));
  createPerformanceIndexes();
};

// getMessages joins/subqueries against these tables by message_row_id
// (and chat by chat_row_id). A real, unmodified WhatsApp database always
// has indexes on these foreign-key columns — but a backup that's been
// re-saved, exported, or processed by another tool can silently lose
// them. Without an index, every correlated subquery (quoted text,
// receipts, revoked, edited...) becomes a full table scan repeated once
// per message row — which is exactly what freezes the tab the instant a
// chat is opened, regardless of how small the page size is. Creating an
// index that already exists is a fast no-op, and this never changes any
// query's results — only how quickly SQLite can answer them.
const createPerformanceIndexes = () => {
  if (!dbInstance) return;
  const indexes: Array<[name: string, table: string, column: string]> = [
    ['idx_message_chat_row_id', 'message', 'chat_row_id'],
    ['idx_message_media_message_row_id', 'message_media', 'message_row_id'],
    ['idx_message_quoted_message_row_id', 'message_quoted', 'message_row_id'],
    ['idx_receipt_user_message_row_id', 'receipt_user', 'message_row_id'],
    ['idx_message_revoked_message_row_id', 'message_revoked', 'message_row_id'],
    ['idx_message_edit_info_message_row_id', 'message_edit_info', 'message_row_id'],
    ['idx_message_call_log_message_row_id', 'message_call_log', 'message_row_id'],
    ['idx_message_location_message_row_id', 'message_location', 'message_row_id'],
    ['idx_message_vcard_message_row_id', 'message_vcard', 'message_row_id'],
    ['idx_jid_map_lid_row_id', 'jid_map', 'lid_row_id'],
    ['idx_jid_map_jid_row_id', 'jid_map', 'jid_row_id'],
    ['idx_message_system_chat_participant', 'message_system_chat_participant', 'message_row_id'],
    ['idx_message_forwarded_message_row_id', 'message_forwarded', 'message_row_id'],
  ];
  for (const [name, table, column] of indexes) {
    try {
      dbInstance.exec(`CREATE INDEX IF NOT EXISTS ${name} ON "${table}"("${column}")`);
    } catch {
      // Table/column doesn't exist in this schema variant (older/newer
      // WhatsApp DB layout) — same best-effort-across-versions approach
      // used everywhere else in this file, just skip it.
    }
  }
};

// ── Helpers ──────────────────────────────────────────────────────
const tryQuery = (sql: string): any[][] | null => {
  try {
    const res = dbInstance.exec(sql);
    return res.length > 0 && res[0].values ? res[0].values : [];
  } catch { return null; }
};

const getColumns = (table: string): string[] => {
  try {
    const res = dbInstance.exec(`PRAGMA table_info("${table}")`);
    if (res.length > 0 && res[0].values) return res[0].values.map((r: any[]) => r[1] as string);
  } catch {}
  return [];
};

const tableExists = (name: string): boolean => {
  try {
    const res = dbInstance.exec(`SELECT name FROM sqlite_master WHERE type='table' AND name='${name}'`);
    return res.length > 0 && res[0].values.length > 0;
  } catch { return false; }
};

// ── DB Schema Inspector ──────────────────────────────────────────
export interface TableInfo {
  name: string;
  columns: string[];
  sampleRows: any[][];
}

export const getDbSchema = (): TableInfo[] => {
  if (!dbInstance) return [];
  const tables = tryQuery(`SELECT name FROM sqlite_master WHERE type='table' ORDER BY name`) ?? [];
  return tables.map((row: any[]) => ({
    name: row[0] as string,
    columns: getColumns(row[0] as string),
    sampleRows: tryQuery(`SELECT * FROM "${row[0]}" LIMIT 2`) ?? [],
  }));
};

// ── Conversations ────────────────────────────────────────────────
export const getConversations = (limit: number = 1000): Conversation[] => {
  if (!dbInstance) return [];

  // Newer WhatsApp databases store the chat JID as a LID. The real
  // phone-number JID is kept in jid_map -> jid, so join it when available.
  const hasJidMap = tableExists('jid_map');
  const mappedJidJoin = hasJidMap
    ? `LEFT JOIN jid_map ON jid_map.lid_row_id = jid._id
       LEFT JOIN jid mapped_jid ON mapped_jid._id = jid_map.jid_row_id`
    : '';
  const mappedJidSelect = hasJidMap
    ? `, mapped_jid.user, mapped_jid.raw_string, mapped_jid.server`
    : `, NULL, NULL, NULL`;

  const hasEphemeral = getColumns('chat').includes('ephemeral_expiration');
  const ephemeralSel = hasEphemeral ? 'chat.ephemeral_expiration' : 'NULL';

  const rows = tryQuery(`
    SELECT
      chat._id,
      jid.user,
      jid.raw_string,
      chat.subject,
      chat.sort_timestamp,
      jid.server,
      chat.jid_row_id,
      ${ephemeralSel} AS ephemeral_expiration
      ${mappedJidSelect}
    FROM chat
    LEFT JOIN jid ON chat.jid_row_id = jid._id
    ${mappedJidJoin}
    ORDER BY chat.sort_timestamp DESC
    LIMIT ${limit}
  `);
  if (rows === null) throw new Error("Failed to query conversations.");
  return rows.map((row: any[]) => ({
    _id: row[0],
    jid_row_id: row[6] ?? 0,
    jid: row[2] || row[1] || 'Unknown',
    phone: formatPhone(
      row[1] || '',
      row[2] || '',
      row[5] || '',
      row[8] || '',
      row[9] || '',
      row[10] || '',
    ),
    subject: row[3],
    timestamp: row[4],
    ephemeralExpiration: row[7] > 0 ? row[7] : undefined,
  }));
};

// Lightweight jid -> display string for the system-event fields below.
// These come from a plain raw_string column (not the full sender
// resolution path with LID -> real-number mapping used elsewhere), so
// this is best-effort: a real phone number if the local part is all
// digits, otherwise whatever identifier is there (still useful for a
// LID or group id, just not guaranteed to be a phone number).
const simplifyJid = (rawString: string | null): string | null => {
  if (!rawString) return null;
  const local = rawString.split('@')[0];
  const digits = local.replace(/\D/g, '');
  if (digits.length >= 7 && digits === local.replace(/^\+/, '')) return '+' + digits;
  return local || null;
};

const formatPhone = (
  user: string,
  rawString: string,
  server: string,
  mappedUser: string,
  mappedRawString: string,
  mappedServer: string,
): string => {
  // Prefer the mapped s.whatsapp.net JID for LID chats. Never turn the
  // opaque LID digits into a fake phone number.
  const directUser = mappedServer === 's.whatsapp.net'
    ? mappedUser
    : server === 's.whatsapp.net'
      ? user
      : '';
  const digits = directUser.replace(/\D/g, '');
  if (digits.length >= 7) return '+' + digits;

  // A direct JID can occasionally have a missing server column; only accept
  // its raw value when it explicitly ends in the phone-number server suffix.
  const directRaw = mappedServer === 's.whatsapp.net'
    ? mappedRawString
    : server === 's.whatsapp.net'
      ? rawString
      : '';
  const rawUser = directRaw.split('@')[0].replace(/\D/g, '');
  return rawUser.length >= 7 ? '+' + rawUser : '';
};

// ── Messages ─────────────────────────────────────────────────────

// message_type values that indicate a media attachment (not just text/link/system)
// Includes both classic and modern WhatsApp schema type codes. Newer
// WhatsApp databases (no `media_wa_type` column, only `message_type`) use
// different numeric codes for the same media kinds — e.g. stickers are 16
// in the classic schema but 20 in the modern one. 28/43/62/81 = video
// variants (GIF/view-once/PTV), 82 = voice note variant.
const MEDIA_TYPES = new Set([1, 2, 3, 4, 9, 13, 14, 15, 16, 20, 26, 28, 42, 43, 62, 81, 82]);

// System/notification message_type codes seen in the modern (message_type
// fallback) WhatsApp schema. These messages have no text/media of their
// own — their real content lives in a related table (call_log,
// message_location, etc.) — so they must be resolved separately instead
// of falling through to a generic "empty message" state.
const CALL_MESSAGE_TYPES = new Set([90]);
const LOCATION_MESSAGE_TYPES = new Set([5]);
// Verified against a real production database: message_type 7 is a
// generic "system event" wrapper (group membership changes, privacy/biz
// notices, number changes, etc.) — every single message_type=7 row had a
// matching `message_system` row, none of them an encryption notice. The
// real event details live in message_system.action_type plus one of
// several message_system_* subtype tables (resolved below).
const SYSTEM_EVENT_TYPES = new Set([7]);
const CONTACT_MESSAGE_TYPES = new Set([4]);
// Album "container" messages (a group of photos/videos sent together).
// Verified via message_album table correlation on message_type = 99.
const ALBUM_MESSAGE_TYPES = new Set([99]);

/** WhatsApp call_result codes that indicate the call was never answered. */
const MISSED_CALL_RESULTS = new Set([2, 4]);

/**
 * How many messages in this chat are "at or newer than" the given message
 * (i.e. its 1-based position counting back from the most recent message).
 * Used to figure out how large a `getMessages` limit needs to be for a
 * specific message to actually be included — `getMessages` only loads the
 * most recent `limit` messages, so jumping to an older search result
 * silently fails to scroll to it unless the limit is raised to cover it
 * first. Returns null if the message or its position can't be resolved.
 */
export const getMessageRank = (chatRowId: number, messageId: number): number | null => {
  if (!dbInstance) return null;
  const msgCols = getColumns('message');
  const orderBy = msgCols.includes('sort_id') ? 'sort_id' : 'timestamp';

  const targetRows = tryQuery(`
    SELECT ${orderBy} FROM message WHERE _id = ${messageId} AND chat_row_id = ${chatRowId}
  `);
  if (!targetRows || targetRows.length === 0) return null;
  const targetOrderValue = targetRows[0][0];
  if (targetOrderValue === null || targetOrderValue === undefined) return null;

  const rankRows = tryQuery(`
    SELECT COUNT(*) FROM message
    WHERE chat_row_id = ${chatRowId} AND ${orderBy} >= ${targetOrderValue}
  `);
  if (!rankRows || rankRows.length === 0) return null;
  return rankRows[0][0] as number;
};

/**
 * Extracts a display name and phone number from raw vCard text stored for
 * shared-contact messages (BEGIN:VCARD ... FN:Name ... TEL...:+123 ...
 * END:VCARD). Falls back gracefully — vCard field folding/escaping varies
 * across exporters, so this only needs to be best-effort.
 */
const parseVcard = (raw: string): ContactVcardInfo => {
  const unfold = raw.replace(/\r\n/g, '\n');
  const fnMatch = unfold.match(/^FN(?:;[^:\n]*)?:(.*)$/mi);
  const nMatch = unfold.match(/^N(?:;[^:\n]*)?:(.*)$/mi);
  const telMatch = unfold.match(/^(?:TEL|item\d+\.TEL)(?:;[^:\n]*)?:(.*)$/mi);

  const unescapeVcard = (s: string) => s
    .replace(/\\n/gi, ' ')
    .replace(/\\,/g, ',')
    .replace(/\\;/g, ';')
    .trim();

  let name: string | null = null;
  if (fnMatch && fnMatch[1].trim()) {
    name = unescapeVcard(fnMatch[1]);
  } else if (nMatch && nMatch[1].trim()) {
    // N is "Last;First;Middle;Prefix;Suffix" — reorder to "First Last".
    const parts = nMatch[1].split(';').map((p) => unescapeVcard(p)).filter(Boolean);
    name = parts.length >= 2 ? `${parts[1]} ${parts[0]}`.trim() : (parts[0] ?? null);
  }

  const phone = telMatch ? unescapeVcard(telMatch[1]) : null;

  return { name, phone };
};

interface ContactVcardInfo {
  name: string | null;
  phone: string | null;
}

/**
 * Reactions (❤️👍😂...) live in message_add_on / message_add_on_reaction,
 * not on the message row itself (confirmed against a real production
 * msgstore.db: message_add_on_type=56 is reactions; empty/NULL reaction
 * values are removed reactions and must be excluded; a message can have
 * reactions from several different people, so this returns a list per
 * message rather than a single value). Fetched once per chat load in a
 * single query rather than per-message, then attached to each Message.
 */
interface RawReaction { emoji: string; fromMe: boolean; senderPhone: string | null }

const REACTION_ADD_ON_TYPE = 56;

const getReactionsForChat = (chatRowId: number): Map<number, RawReaction[]> => {
  const map = new Map<number, RawReaction[]>();
  if (!dbInstance) return map;
  if (!tableExists('message_add_on') || !tableExists('message_add_on_reaction')) return map;

  // Reactor identity resolution mirrors the group-message sender
  // resolution above (same LID -> real phone number mapping), just
  // against message_add_on.sender_jid_row_id instead of message's.
  const hasJidMap = tableExists('jid_map');
  const reactorJoin = `
    LEFT JOIN jid reactor_jid ON reactor_jid._id = mao.sender_jid_row_id
    ${hasJidMap ? `LEFT JOIN jid_map reactor_jid_map ON reactor_jid_map.lid_row_id = reactor_jid._id
    LEFT JOIN jid reactor_mapped_jid ON reactor_mapped_jid._id = reactor_jid_map.jid_row_id` : ''}`;
  const reactorSel = `reactor_jid.user, reactor_jid.raw_string, reactor_jid.server${
    hasJidMap ? ', reactor_mapped_jid.user, reactor_mapped_jid.raw_string, reactor_mapped_jid.server' : ', NULL, NULL, NULL'
  }`;

  const rows = tryQuery(`
    SELECT mao.parent_message_row_id, mao.from_me, mar.reaction, ${reactorSel}
    FROM message_add_on mao
    JOIN message_add_on_reaction mar ON mar.message_add_on_row_id = mao._id
    ${reactorJoin}
    WHERE mao.chat_row_id = ${chatRowId}
      AND mao.message_add_on_type = ${REACTION_ADD_ON_TYPE}
      AND mar.reaction IS NOT NULL AND mar.reaction != ''
    ORDER BY mao.timestamp ASC
  `);
  if (!rows) return map;

  rows.forEach((row: any[]) => {
    const parentId = row[0] as number;
    if (parentId == null) return;
    const fromMe = row[1] === 1;
    const emoji = String(row[2]);
    const senderPhone = fromMe ? null : (formatPhone(
      row[3] || '', row[4] || '', row[5] || '',
      row[6] || '', row[7] || '', row[8] || '',
    ) || null);
    const list = map.get(parentId) ?? [];
    list.push({ emoji, fromMe, senderPhone });
    map.set(parentId, list);
  });
  return map;
};

export const getMessages = (chatRowId: number, limit: number = -1, offset: number = 0): Message[] => {
  const messages = getMessagesCore(chatRowId, limit, offset);
  if (messages.length === 0) return messages;
  const reactionsByMessage = getReactionsForChat(chatRowId);
  const withReactions = reactionsByMessage.size === 0 ? messages : messages.map((m) => {
    const reactions = reactionsByMessage.get(m._id);
    return reactions && reactions.length ? { ...m, reactions } : m;
  });
  return resolveMentions(withReactions);
};

// WhatsApp embeds @mentions directly in text_data as "@<jid user-part>".
// On modern accounts that user-part is very often a LID (a long
// privacy-preserving id like "243976271601845") rather than the real
// phone number — the real number is only reachable via jid_map, same
// LID -> real-number indirection used everywhere else in this file.
// Resolve every distinct mentioned number across the whole page in one
// batch query rather than per-message/per-mention.
const MENTION_REGEX = /@(\d{5,})/g;

const resolveMentions = (messages: Message[]): Message[] => {
  if (!dbInstance) return messages;
  const mentioned = new Set<string>();
  for (const m of messages) {
    MENTION_REGEX.lastIndex = 0;
    let match: RegExpExecArray | null;
    if (m.text_data) {
      while ((match = MENTION_REGEX.exec(m.text_data)) !== null) mentioned.add(match[1]);
    }
    MENTION_REGEX.lastIndex = 0;
    if (m.quoted_text) {
      while ((match = MENTION_REGEX.exec(m.quoted_text)) !== null) mentioned.add(match[1]);
    }
  }
  if (mentioned.size === 0) return messages;

  const hasJidMap = tableExists('jid_map');
  const digitsList = Array.from(mentioned).map((d) => `'${d}'`).join(',');
  const rows = tryQuery(`
    SELECT jid.user, jid.raw_string, jid.server
      ${hasJidMap ? ', mapped_jid.user, mapped_jid.raw_string, mapped_jid.server' : ''}
    FROM jid
    ${hasJidMap ? `LEFT JOIN jid_map ON jid_map.lid_row_id = jid._id
    LEFT JOIN jid mapped_jid ON mapped_jid._id = jid_map.jid_row_id` : ''}
    WHERE jid.user IN (${digitsList})
  `);
  if (!rows || rows.length === 0) return messages;

  const resolvedByDigits = new Map<string, string>();
  rows.forEach((row: any[]) => {
    const originalDigits = String(row[0]);
    const phone = formatPhone(
      row[0] || '', row[1] || '', row[2] || '',
      hasJidMap ? row[3] || '' : '', hasJidMap ? row[4] || '' : '', hasJidMap ? row[5] || '' : '',
    );
    // WhatsApp itself shows mentions without the leading "+".
    if (phone) resolvedByDigits.set(originalDigits, phone.replace(/^\+/, ''));
  });
  if (resolvedByDigits.size === 0) return messages;

  return messages.map((m) => {
    const rewrite = (text: string) => text.replace(MENTION_REGEX, (full, digits) => {
      const resolved = resolvedByDigits.get(digits);
      return resolved ? `@${resolved}` : full; // leave unresolved ones as-is rather than guessing
    });
    const newText = m.text_data ? rewrite(m.text_data) : m.text_data;
    const newQuoted = m.quoted_text ? rewrite(m.quoted_text) : m.quoted_text;
    if (newText === m.text_data && newQuoted === m.quoted_text) return m;
    return { ...m, text_data: newText, quoted_text: newQuoted };
  });
};

const getMessagesCore = (chatRowId: number, limit: number = -1, offset: number = 0): Message[] => {
  if (!dbInstance) return [];

  const msgCols   = getColumns('message');
  const orderBy   = msgCols.includes('sort_id') ? 'message.sort_id' : 'message.timestamp';
  const typeCol   = msgCols.includes('media_wa_type') ? 'message.media_wa_type' : 'message.message_type';
  const hasQuoted = tableExists('message_quoted');
  const quotedSel = hasQuoted
    ? `(SELECT text_data FROM message_quoted WHERE message_quoted.message_row_id = message._id LIMIT 1)`
    : `NULL`;

  // Group messages carry who sent them in `sender_jid_row_id` (NULL for
  // 1:1 chats, and for the local user's own messages). Resolve it the same
  // way `getConversations` resolves a chat's own JID, including the
  // LID -> real phone number mapping for modern databases.
  const hasSenderCol = msgCols.includes('sender_jid_row_id');
  const hasJidMap = tableExists('jid_map');
  const senderJoin = hasSenderCol
    ? `LEFT JOIN jid sender_jid ON sender_jid._id = message.sender_jid_row_id
       ${hasJidMap ? `LEFT JOIN jid_map sender_jid_map ON sender_jid_map.lid_row_id = sender_jid._id
       LEFT JOIN jid sender_mapped_jid ON sender_mapped_jid._id = sender_jid_map.jid_row_id` : ''}`
    : '';
  const senderSel = hasSenderCol
    ? `sender_jid.user, sender_jid.raw_string, sender_jid.server${
        hasJidMap ? ', sender_mapped_jid.user, sender_mapped_jid.raw_string, sender_mapped_jid.server' : ', NULL, NULL, NULL'
      }`
    : 'NULL, NULL, NULL, NULL, NULL, NULL';

  const resolveSenderPhone = (row: any[], offset: number): string | null => {
    if (!hasSenderCol) return null;
    const phone = formatPhone(
      row[offset] || '', row[offset + 1] || '', row[offset + 2] || '',
      row[offset + 3] || '', row[offset + 4] || '', row[offset + 5] || '',
    );
    return phone || null;
  };

  // ── Try with message_media JOIN ──────────────────────────────
  if (tableExists('message_media')) {
    const mmCols = getColumns('message_media');

    // Pick best filename source. Real-world msgstore databases store TWO
    // different name-like values here: `file_path` is the actual local
    // filename WhatsApp saved the file under (e.g.
    // "Media/WhatsApp Voice Notes/202401/PTT-20241230-WA0031.opus"), while
    // `media_name` is very often an internal hash-style identifier (e.g.
    // "3c9ed633ff7e4e5caf5b5bda25a0390d.opus") that looks like a filename
    // but does NOT correspond to the real file on disk. `file_path` is
    // therefore the reliable one to match local files by — but it
    // occasionally has no extension (ends with a bare "."), in which case
    // fall back to `media_name` (or synthesize one from mime_type).
    const captionCol   = ['media_caption', 'caption'].find(c => mmCols.includes(c)) ?? null;
    const mimeCol      = ['mime_type', 'media_mime_type'].find(c => mmCols.includes(c)) ?? null;
    const durationCol  = ['media_duration', 'duration'].find(c => mmCols.includes(c)) ?? null;
    const sizeCol      = ['file_size', 'file_length', 'media_size'].find(c => mmCols.includes(c)) ?? null;
    const directPath   = mmCols.includes('direct_path') ? 'mm.direct_path' : 'NULL';
    const mediaKey     = mmCols.includes('media_key') ? 'mm.media_key' : 'NULL';

    const filePathSel  = mmCols.includes('file_path')  ? 'mm.file_path'  : 'NULL';
    const mediaNameSel = mmCols.includes('media_name') ? 'mm.media_name' : 'NULL';
    const captionSel   = captionCol  ? `mm.${captionCol}`  : 'NULL';
    const mimeSel      = mimeCol     ? `mm.${mimeCol}`     : 'NULL';
    const durationSel  = durationCol ? `mm.${durationCol}` : 'NULL';
    const sizeSel      = sizeCol     ? `mm.${sizeCol}`     : 'NULL';

    // System message data: calls and locations live in their own tables,
    // not in message_media, so resolve them via separate optional joins.
    const hasCallLog = tableExists('message_call_log') && tableExists('call_log');

    const callJoin = hasCallLog
      ? `LEFT JOIN message_call_log mcl ON mcl.message_row_id = message._id
         LEFT JOIN call_log cl ON cl._id = mcl.call_log_row_id`
      : '';
    const callVideoSel = hasCallLog ? 'cl.video_call' : 'NULL';
    const callDurationSel = hasCallLog ? 'cl.duration' : 'NULL';
    const callResultSel = hasCallLog ? 'cl.call_result' : 'NULL';

    const hasLocation = tableExists('message_location');
    const locationJoin = hasLocation
      ? 'LEFT JOIN message_location mloc ON mloc.message_row_id = message._id'
      : '';
    const latSel = hasLocation ? 'mloc.latitude' : 'NULL';
    const lngSel = hasLocation ? 'mloc.longitude' : 'NULL';
    const placeNameSel = hasLocation ? 'mloc.place_name' : 'NULL';

    // Shared-contact ("vCard") messages carry no file — the media_media
    // row for them has no name/caption at all, which is why they used to
    // show as "No filename stored". The actual contact data lives in its
    // own table as raw vCard text (BEGIN:VCARD ... FN:Name ... END:VCARD).
    const hasVcard = tableExists('message_vcard');
    const vcardCols = hasVcard ? getColumns('message_vcard') : [];
    const vcardCol = ['vcard', 'data'].find(c => vcardCols.includes(c)) ?? null;
    const vcardJoin = vcardCol
      ? 'LEFT JOIN message_vcard mvc ON mvc.message_row_id = message._id'
      : '';
    const vcardSel = vcardCol ? `mvc.${vcardCol}` : 'NULL';

    // Read/delivery receipts. Using correlated subqueries (rather than a
    // JOIN) avoids row fan-out for group chats, where a single message can
    // have one receipt_user row per recipient.
    const hasReceipts = tableExists('receipt_user');
    const receiptCountSel = hasReceipts
      ? '(SELECT COUNT(*) FROM receipt_user ru WHERE ru.message_row_id = message._id)'
      : 'NULL';
    const receiptReadCountSel = hasReceipts
      ? '(SELECT COUNT(*) FROM receipt_user ru WHERE ru.message_row_id = message._id AND ru.read_timestamp IS NOT NULL)'
      : 'NULL';
    const receiptDeliveredCountSel = hasReceipts
      ? '(SELECT COUNT(*) FROM receipt_user ru WHERE ru.message_row_id = message._id AND ru.receipt_timestamp IS NOT NULL)'
      : 'NULL';

    // Deleted ("revoked") and edited messages. Detected via EXISTS on
    // their dedicated tables rather than trusting message_type alone —
    // in this schema revoked messages are usually retyped to 15, but a
    // handful keep their original media type, so the join is the source
    // of truth.
    const hasRevoked = tableExists('message_revoked');
    const revokedSel = hasRevoked
      ? '(SELECT 1 FROM message_revoked mrv WHERE mrv.message_row_id = message._id LIMIT 1)'
      : 'NULL';

    const hasEditInfo = tableExists('message_edit_info');
    const editedTsSel = hasEditInfo
      ? '(SELECT edited_timestamp FROM message_edit_info mei WHERE mei.message_row_id = message._id LIMIT 1)'
      : 'NULL';

    const hasForwarded = tableExists('message_forwarded');
    const forwardScoreSel = hasForwarded
      ? '(SELECT forward_score FROM message_forwarded mf WHERE mf.message_row_id = message._id LIMIT 1)'
      : 'NULL';

    const hasAlbum = tableExists('message_album');
    const albumImageCountSel = hasAlbum
      ? '(SELECT image_count FROM message_album ma WHERE ma.message_row_id = message._id LIMIT 1)'
      : 'NULL';
    const albumVideoCountSel = hasAlbum
      ? '(SELECT video_count FROM message_album ma WHERE ma.message_row_id = message._id LIMIT 1)'
      : 'NULL';

    // System events (message_type 7 — see SYSTEM_EVENT_TYPES above). Real
    // content lives across several message_system_* subtype tables, each
    // covering a different kind of event. Every subquery here is guarded
    // by a CASE on the type column so it's only ever evaluated for the
    // small fraction of rows that are actually system events (~2.7% in a
    // real production database) — same "index everything, but also only
    // run what's needed" approach as the rest of this file.
    const sysGuard = (sql: string) => `CASE WHEN ${typeCol} = 7 THEN ${sql} ELSE NULL END`;

    const hasSysChatParticipant = tableExists('message_system_chat_participant');
    const sysParticipantSel = hasSysChatParticipant
      ? sysGuard(`(SELECT (SELECT raw_string FROM jid WHERE jid._id = sp.user_jid_row_id)
                   FROM message_system_chat_participant sp WHERE sp.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysGroup = tableExists('message_system_group');
    const sysGroupSel = hasSysGroup
      ? sysGuard(`(SELECT 1 FROM message_system_group sg WHERE sg.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysPhotoChange = tableExists('message_system_photo_change');
    const sysPhotoChangeSel = hasSysPhotoChange
      ? sysGuard(`(SELECT 1 FROM message_system_photo_change pc WHERE pc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysNumberChange = tableExists('message_system_number_change');
    const sysNumberOldSel = hasSysNumberChange
      ? sysGuard(`(SELECT (SELECT raw_string FROM jid WHERE jid._id = nc.old_jid_row_id)
                   FROM message_system_number_change nc WHERE nc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';
    const sysNumberNewSel = hasSysNumberChange
      ? sysGuard(`(SELECT (SELECT raw_string FROM jid WHERE jid._id = nc.new_jid_row_id)
                   FROM message_system_number_change nc WHERE nc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysUsernameChange = tableExists('message_system_username_change');
    const sysUsernameOldSel = hasSysUsernameChange
      ? sysGuard(`(SELECT old_username FROM message_system_username_change uc WHERE uc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';
    const sysUsernameNewSel = hasSysUsernameChange
      ? sysGuard(`(SELECT new_username FROM message_system_username_change uc WHERE uc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysValueChange = tableExists('message_system_value_change');
    const sysValueOldDataSel = hasSysValueChange
      ? sysGuard(`(SELECT old_data FROM message_system_value_change vc WHERE vc.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const hasSysPrivacyProvider = tableExists('message_system_initial_privacy_provider');
    const sysPrivacyProviderSel = hasSysPrivacyProvider
      ? sysGuard(`(SELECT 1 FROM message_system_initial_privacy_provider pp WHERE pp.message_row_id = message._id LIMIT 1)`)
      : 'NULL';

    const rows = tryQuery(`
      SELECT
        message._id,
        message.from_me,
        message.text_data,
        message.timestamp,
        ${quotedSel}     AS quoted_text,
        ${typeCol}       AS msg_type,
        ${filePathSel}   AS raw_file_path,
        ${sizeSel}       AS file_size,
        ${captionSel}    AS media_caption,
        ${durationSel}   AS media_duration,
        ${mimeSel}       AS mime_type,
        ${directPath}    AS direct_path,
        ${mediaNameSel}  AS raw_media_name,
        ${mediaKey}      AS media_key,
        ${callVideoSel}    AS call_video,
        ${callDurationSel} AS call_duration,
        ${callResultSel}   AS call_result,
        ${latSel}          AS loc_lat,
        ${lngSel}          AS loc_lng,
        ${placeNameSel}    AS loc_place,
        ${vcardSel}        AS vcard_data,
        ${receiptCountSel}          AS receipt_count,
        ${receiptReadCountSel}      AS receipt_read_count,
        ${receiptDeliveredCountSel} AS receipt_delivered_count,
        ${revokedSel}    AS is_revoked_raw,
        ${editedTsSel}   AS edited_ts,
        ${forwardScoreSel} AS forward_score,
        ${albumImageCountSel} AS album_image_count,
        ${albumVideoCountSel} AS album_video_count,
        ${sysParticipantSel}  AS sys_participant_jid,
        ${sysGroupSel}        AS sys_group_flag,
        ${sysPhotoChangeSel}  AS sys_photo_change,
        ${sysNumberOldSel}    AS sys_number_old_jid,
        ${sysNumberNewSel}    AS sys_number_new_jid,
        ${sysUsernameOldSel}  AS sys_username_old,
        ${sysUsernameNewSel}  AS sys_username_new,
        ${sysValueOldDataSel} AS sys_value_old_data,
        ${sysPrivacyProviderSel} AS sys_privacy_provider,
        ${senderSel}
      FROM message
      LEFT JOIN message_media mm ON mm.message_row_id = message._id
      ${callJoin}
      ${locationJoin}
      ${vcardJoin}
      ${senderJoin}
      WHERE message.chat_row_id = ${chatRowId}
      ORDER BY ${orderBy} DESC
      LIMIT ${limit} OFFSET ${offset}
    `);

    if (rows !== null) {
      return rows.map((row: any[]) => {
        const textData    = row[2];
        const msgType     = row[5] as number | null;
        const rawFilePath = row[6] ? String(row[6]) : null;
        const fileSize    = row[7] as number | null;
        const caption     = row[8] ? String(row[8]) : null;
        const duration    = row[9] as number | null;
        const mimeType    = row[10] ? String(row[10]) : null;
        const directPath  = row[11] ? String(row[11]) : null;
        const rawMediaName = row[12] ? String(row[12]) : null;
        const mediaKey    = row[13] ?? null;
        const callVideo    = row[14];
        const callDuration = row[15] as number | null;
        const callResult   = row[16] as number | null;
        const locLat   = row[17] as number | null;
        const locLng   = row[18] as number | null;
        const locPlace = row[19] ? String(row[19]) : null;
        const vcardRaw = row[20] ? String(row[20]) : null;
        const receiptCount    = row[21] as number | null;
        const receiptReadCount = row[22] as number | null;
        const receiptDeliveredCount = row[23] as number | null;
        const isRevokedRaw = row[24];
        const editedTs = row[25] as number | null;
        const forwardScore = row[26] as number | null;
        const albumImageCount = row[27] as number | null;
        const albumVideoCount = row[28] as number | null;
        const sysParticipantJid = row[29] ? String(row[29]) : null;
        const sysGroupFlag = row[30];
        const sysPhotoChangeFlag = row[31];
        const sysNumberOldJid = row[32] ? String(row[32]) : null;
        const sysNumberNewJid = row[33] ? String(row[33]) : null;
        const sysUsernameOld = row[34] ? String(row[34]) : null;
        const sysUsernameNew = row[35] ? String(row[35]) : null;
        const sysValueOldData = row[36] ? String(row[36]) : null;
        const sysPrivacyProviderFlag = row[37];
        const senderPhone = resolveSenderPhone(row, 38);

        // Determine if this message has media
        const isRevoked = isRevokedRaw != null;
        // A revoked message's DB row sometimes still carries its old media
        // type (e.g. 1 = image) even though the actual file is gone —
        // never treat a deleted message as having renderable media.
        const hasMedia = !isRevoked && msgType != null && MEDIA_TYPES.has(msgType);

        // Build best display filename, tracking whether it came from a
        // real database column (reliable) or was synthesized as a
        // best-effort guess (unreliable — can't be matched to a local file).
        //
        // `file_path` (a real local path like ".../PTT-20241230-WA0031.opus")
        // is normally the trustworthy one; `media_name` is frequently an
        // internal hash-style value with no relation to the file on disk
        // (e.g. "3c9ed633ff7e4e5caf5b5bda25a0390d.opus"). Prefer file_path's
        // basename whenever it has a real extension. Keep whichever of the
        // two we DIDN'T pick as an alternate candidate — some backups really
        // do save files under the media_name-style name instead, so local
        // file matching gets to try both rather than committing to one.
        const hasExt = (name: string) => /\.[^./\\]{1,8}$/.test(name);
        const withExtFromMime = (name: string): string => {
          if (hasExt(name)) return name;
          const stripped = name.replace(/\.$/, '');
          const ext = mimeType ? mimeToExt(mimeType) : null;
          return ext ? `${stripped}.${ext}` : stripped;
        };

        const rawFromPath = rawFilePath ? extractFileName(rawFilePath) : null;
        const rawFromName = rawMediaName || null;

        let mediaName: string | null = null;
        let mediaAltName: string | null = null;
        let mediaNameReliable = true;

        if (rawFromPath && hasExt(rawFromPath)) {
          // The common, reliable case: file_path already names a real file.
          mediaName = rawFromPath;
          mediaAltName = rawFromName && rawFromName !== rawFromPath ? rawFromName : null;
        } else if (rawFromName && hasExt(rawFromName)) {
          // file_path was unusable (missing/no extension) but media_name
          // already has one — e.g. some Document shares store the original
          // device filename ("IMG_20250104_015606_579.jpg") in media_name
          // while file_path is left incomplete.
          mediaName = rawFromName;
          mediaAltName = rawFromPath && rawFromPath !== rawFromName ? rawFromPath : null;
        } else {
          // Neither candidate has a usable extension as-is — best-effort
          // guess one from the mime type onto whichever value exists.
          const guessed = rawFromPath ? withExtFromMime(rawFromPath)
                        : rawFromName ? withExtFromMime(rawFromName)
                        : null;
          mediaName = guessed;
          mediaAltName = null;
          if (!guessed || !hasExt(guessed)) mediaNameReliable = false;
        }


        // Fallback: extract something meaningful from direct_path — this is
        // derived from WhatsApp's server-side CDN path, not the real local
        // filename, so it will almost never match a file on disk. Reaching
        // this point at all means the database never recorded a real local
        // filename (file_path/media_name) for this message — WhatsApp most
        // likely never downloaded/saved a local copy of it in the first
        // place, so no amount of matching logic can ever find it locally.
        let mediaNeverDownloaded = false;
        if (!mediaName && directPath) {
          mediaName = extractFileNameFromCDN(directPath, mimeType);
          mediaNameReliable = false;
          mediaNeverDownloaded = true;
        }
        // Fallback: generate name from mime_type — also synthetic.
        if (!mediaName && mimeType) {
          mediaName = generateNameFromMime(mimeType, msgType);
          mediaNameReliable = false;
          mediaNeverDownloaded = true;
        }

        // System messages: calls, location shares, generic system events
        // (group changes, privacy notices, etc). These carry no text/media
        // of their own — resolve from their dedicated tables instead of
        // showing a generic empty state or (the old bug) a hardcoded
        // "encrypted" notice that doesn't actually describe the event.
        let systemKind: Message['system_kind'];
        let callInfo: Message['call_info'];
        let locationInfo: Message['location_info'];
        let contactInfo: Message['contact_info'];
        let systemEvent: Message['system_event'];

        if (msgType != null && CALL_MESSAGE_TYPES.has(msgType)) {
          systemKind = 'call';
          callInfo = {
            video: callVideo === 1,
            duration: callDuration ?? 0,
            missed: callResult != null && MISSED_CALL_RESULTS.has(callResult),
          };
        } else if (msgType != null && LOCATION_MESSAGE_TYPES.has(msgType)) {
          systemKind = 'location';
          locationInfo = { latitude: locLat, longitude: locLng, placeName: locPlace };
        } else if (msgType != null && SYSTEM_EVENT_TYPES.has(msgType)) {
          systemKind = 'system_event';
          // Priority mirrors real-world frequency/specificity: a named
          // participant is the most informative thing we can show, so
          // check for that first; the broad privacy/business notice is
          // checked last since it carries the least detail.
          if (sysParticipantJid) {
            systemEvent = { kind: 'group_participant', personJid: simplifyJid(sysParticipantJid) };
          } else if (sysUsernameOld || sysUsernameNew) {
            systemEvent = { kind: 'username_change', oldValue: sysUsernameOld, newValue: sysUsernameNew };
          } else if (sysNumberOldJid || sysNumberNewJid) {
            systemEvent = { kind: 'number_change', oldValue: simplifyJid(sysNumberOldJid), newValue: simplifyJid(sysNumberNewJid) };
          } else if (sysPhotoChangeFlag != null) {
            systemEvent = { kind: 'group_photo' };
          } else if (sysValueOldData) {
            systemEvent = { kind: 'group_info_change', oldValue: sysValueOldData };
          } else if (sysGroupFlag != null) {
            systemEvent = { kind: 'group_self' };
          } else if (sysPrivacyProviderFlag != null) {
            systemEvent = { kind: 'business_notice' };
          } else {
            systemEvent = { kind: 'other' };
          }
        } else if (msgType != null && ALBUM_MESSAGE_TYPES.has(msgType)) {
          systemKind = 'album';
        }

        let albumInfo: Message['album_info'];
        if (systemKind === 'album') {
          albumInfo = {
            imageCount: albumImageCount ?? 0,
            videoCount: albumVideoCount ?? 0,
          };
        }

        if (msgType != null && CONTACT_MESSAGE_TYPES.has(msgType) && vcardRaw) {
          const parsed = parseVcard(vcardRaw);
          if (parsed.name || parsed.phone) {
            contactInfo = parsed;
          }
        }

        // Only meaningful for messages the user sent. A message with zero
        // receipt_user rows (e.g. very old messages, or before receipts
        // were tracked) is left as 'sent' — the safe single-check default.
        let receiptStatus: Message['receipt_status'];
        if (row[1] === 1 && receiptCount != null) {
          if (receiptCount > 0 && receiptReadCount === receiptCount) {
            receiptStatus = 'read';
          } else if ((receiptDeliveredCount ?? 0) > 0) {
            receiptStatus = 'delivered';
          } else {
            receiptStatus = 'sent';
          }
        }

        return {
          _id: row[0],
          from_me: row[1] === 1,
          text_data: textData,
          timestamp: new Date(row[3]),
          quoted_text: row[4],
          has_media: hasMedia,
          media_wa_type: msgType ?? undefined,
          media_name: mediaName,
          media_name_reliable: mediaNameReliable,
          media_never_downloaded: mediaNeverDownloaded,
          media_alt_name: mediaAltName,
          media_size: fileSize,
          media_caption: caption,
          media_duration: duration,
          media_mime_type: mimeType,
          media_direct_path: directPath,
          media_key: mediaKey,
          system_kind: systemKind,
          system_event: systemEvent,
          call_info: callInfo,
          location_info: locationInfo,
          album_info: albumInfo,
          contact_info: contactInfo,
          sender_phone: senderPhone,
          receipt_status: receiptStatus,
          is_revoked: isRevoked,
          is_edited: editedTs != null,
          edited_timestamp: editedTs != null ? new Date(editedTs) : undefined,
          is_forwarded: forwardScore != null && forwardScore > 0,
          forwarded_many_times: forwardScore != null && forwardScore >= 5,
        };
      }).reverse();
    }
  }

  // ── Fallback: no message_media join ─────────────────────────
  const rows = tryQuery(`
    SELECT message._id, message.from_me, message.text_data, message.timestamp,
           ${quotedSel} AS quoted_text,
           ${typeCol}   AS msg_type,
           ${senderSel}
    FROM message
    ${senderJoin}
    WHERE message.chat_row_id = ${chatRowId}
    ORDER BY ${orderBy} DESC
    LIMIT ${limit} OFFSET ${offset}
  `);

  if (rows !== null) {
    return rows.map((row: any[]) => {
      const msgType = row[5] as number | null;
      return {
        _id: row[0],
        from_me: row[1] === 1,
        text_data: row[2],
        timestamp: new Date(row[3]),
        quoted_text: row[4],
        has_media: msgType != null && MEDIA_TYPES.has(msgType),
        media_wa_type: msgType ?? undefined,
        sender_phone: resolveSenderPhone(row, 6),
      };
    }).reverse();
  }

  // ── Last resort: minimum columns ─────────────────────────────
  const minRows = tryQuery(`
    SELECT _id, from_me, text_data, timestamp
    FROM message
    WHERE chat_row_id = ${chatRowId}
    ORDER BY timestamp DESC
    LIMIT ${limit} OFFSET ${offset}
  `);
  return (minRows ?? []).map((row: any[]) => ({
    _id: row[0],
    from_me: row[1] === 1,
    text_data: row[2],
    timestamp: new Date(row[3]),
    quoted_text: null,
    has_media: row[2] === null,
  })).reverse();
};

// ── Search ───────────────────────────────────────────────────────
export interface SearchResult {
  messageId: number;
  chatRowId: number;
  fromMe: boolean;
  timestamp: Date;
  snippet: string;
  matchField: 'text' | 'caption';
}

/** Escape SQL LIKE wildcards (%, _) and the backslash escape char itself. */
const escapeLike = (value: string): string =>
  value.replace(/[\\%_]/g, (ch) => `\\${ch}`);

/** Escape single quotes for safe inline SQL string literals. */
const escapeSqlString = (value: string): string => value.replace(/'/g, "''");

export const searchMessages = (query: string, limit: number = 300): SearchResult[] => {
  const trimmed = query.trim();
  if (!dbInstance || trimmed.length === 0) return [];

  const needle = escapeSqlString(escapeLike(trimmed));
  const msgCols = getColumns('message');
  const orderBy = msgCols.includes('sort_id') ? 'message.sort_id' : 'message.timestamp';

  let captionSel = 'NULL';
  let captionJoin = '';
  if (tableExists('message_media')) {
    const mmCols = getColumns('message_media');
    const captionCol = ['media_caption', 'caption'].find((c) => mmCols.includes(c));
    if (captionCol) {
      captionJoin = `LEFT JOIN message_media mm ON mm.message_row_id = message._id`;
      captionSel = `mm.${captionCol}`;
    }
  }

  const captionCondition = captionSel !== 'NULL'
    ? ` OR ${captionSel} LIKE '%${needle}%' ESCAPE '\\'`
    : '';

  const rows = tryQuery(`
    SELECT
      message._id,
      message.chat_row_id,
      message.from_me,
      message.text_data,
      message.timestamp,
      ${captionSel} AS caption
    FROM message
    ${captionJoin}
    WHERE (message.text_data LIKE '%${needle}%' ESCAPE '\\'${captionCondition})
    ORDER BY ${orderBy} DESC
    LIMIT ${limit}
  `);

  if (!rows) return [];

  const lowerQuery = trimmed.toLowerCase();
  return rows.map((row: any[]) => {
    const text = row[3] !== null && row[3] !== undefined ? String(row[3]) : null;
    const caption = row[5] !== null && row[5] !== undefined ? String(row[5]) : null;
    const textMatches = !!text && text.toLowerCase().includes(lowerQuery);
    const snippet = textMatches ? text : (caption ?? text ?? '');
    return {
      messageId: row[0],
      chatRowId: row[1],
      fromMe: row[2] === 1,
      timestamp: new Date(row[4]),
      snippet,
      matchField: textMatches ? 'text' : 'caption',
    };
  });
};

// ── Filename Utilities ───────────────────────────────────────────

/** Extract the last segment of a local file path */
const extractFileName = (filePath: string): string => {
  if (!filePath) return '';
  const parts = filePath.replace(/\?.*$/, '').split(/[/\\]/);
  return parts[parts.length - 1] || filePath;
};

/** Extract a display name from a WhatsApp CDN path */
const extractFileNameFromCDN = (directPath: string, mime: string | null): string | null => {
  if (!directPath) return null;
  // Strip query string, grab last path segment
  const clean = directPath.replace(/\?.*$/, '');
  const parts  = clean.split('/');
  const segment = parts[parts.length - 1];
  if (!segment) return null;
  // Older-style CDN paths end in ".enc"; replace it with a real extension.
  // Newer-style paths (used for images since ~2024, e.g.
  // "/o1/v/t62.../f2/m233/AQPy1uE4Kw...") have no extension at all — add
  // one from the mime type either way, purely for readability, since this
  // is always just WhatsApp's server-side media token, never a real local
  // filename (this whole fallback only runs when the database has no
  // file_path/media_name at all for the message).
  const withoutEnc = segment.endsWith('.enc') ? segment.slice(0, -4) : segment;
  if (/\.[^./\\]{1,8}$/.test(withoutEnc)) return withoutEnc;
  const ext = mime ? mimeToExt(mime) : null;
  return ext ? `${withoutEnc}.${ext}` : withoutEnc;
};

/** Generate a human-readable name when nothing else is available */
const generateNameFromMime = (mime: string, msgType: number | null): string => {
  const ext = mimeToExt(mime) ?? 'bin';
  const label = getMediaLabel(msgType);
  return `${label.toLowerCase()}.${ext}`;
};

const mimeToExt = (mime: string): string | null => {
  const m = mime.split(';')[0].trim().toLowerCase();
  const map: Record<string, string> = {
    'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png',
    'image/gif': 'gif', 'image/webp': 'webp', 'image/heic': 'heic',
    'video/mp4': 'mp4', 'video/3gpp': '3gp', 'video/quicktime': 'mov',
    'video/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mpeg': 'mp3',
    'audio/mp4': 'm4a', 'audio/aac': 'aac', 'audio/wav': 'wav',
    'application/pdf': 'pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/zip': 'zip',
  };
  return map[m] ?? null;
};

// ── Display Helpers ──────────────────────────────────────────────

export const formatFileSize = (bytes: number | null | undefined): string => {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

export const getMediaLabel = (waType: number | null | undefined): string => {
  switch (waType) {
    case 1:  return 'Image';
    case 2:  return 'Audio';
    case 3:  return 'Video';
    case 4:  return 'Contact';
    case 5:  return 'Location';
    case 7:  return 'Link';
    case 8:  return 'Document';
    case 9:  return 'Voice';
    case 13: return 'Video';
    case 14: return 'GIF';
    case 15: return 'Document';
    case 16: return 'Sticker';
    case 20: return 'Sticker';
    case 26: return 'Audio';
    case 28: return 'Video';
    case 43: return 'Video';
    case 62: return 'Video';
    case 81: return 'Video';
    case 82: return 'Voice';
    default: return 'Media';
  }
};

// ── Group Members ────────────────────────────────────────────────
export interface GroupMember {
  jidRowId: number;
  phone: string;
  /** 0 = regular member, 1 = admin, 2 = owner/super-admin. */
  rank: number;
  addTimestamp: number | null;
}

export interface PastGroupMember {
  jidRowId: number;
  phone: string;
  /** True if they left voluntarily; false typically means removed by an admin. */
  leftVoluntarily: boolean;
  timestamp: number | null;
}

export interface GroupMembersResult {
  current: GroupMember[];
  past: PastGroupMember[];
}

/** Resolves a jid row (with optional LID mapping) to a displayable phone
 *  number string, reusing the same logic as getConversations(). */
const resolveJidPhone = (
  user: string | null, rawString: string | null, server: string | null,
  mappedUser: string | null, mappedRawString: string | null, mappedServer: string | null,
): string =>
  formatPhone(user || '', rawString || '', server || '', mappedUser || '', mappedRawString || '', mappedServer || '');

export const getGroupMembers = (chatJidRowId: number): GroupMembersResult => {
  if (!dbInstance) return { current: [], past: [] };
  if (!tableExists('group_participant_user')) return { current: [], past: [] };

  const hasJidMap = tableExists('jid_map');
  const mappedJidJoin = hasJidMap
    ? `LEFT JOIN jid_map ON jid_map.lid_row_id = j._id
       LEFT JOIN jid mapped_jid ON mapped_jid._id = jid_map.jid_row_id`
    : '';
  const mappedJidSelect = hasJidMap
    ? `, mapped_jid.user, mapped_jid.raw_string, mapped_jid.server`
    : `, NULL, NULL, NULL`;

  const currentRows = tryQuery(`
    SELECT gpu.user_jid_row_id, j.user, j.raw_string, j.server, gpu.rank, gpu.add_timestamp
      ${mappedJidSelect}
    FROM group_participant_user gpu
    LEFT JOIN jid j ON j._id = gpu.user_jid_row_id
    ${mappedJidJoin}
    WHERE gpu.group_jid_row_id = ${chatJidRowId}
    ORDER BY gpu.rank DESC, gpu.add_timestamp ASC
  `) ?? [];

  const current: GroupMember[] = currentRows.map((row: any[]) => ({
    jidRowId: row[0],
    phone: resolveJidPhone(row[1], row[2], row[3], row[6], row[7], row[8]) || String(row[1] ?? row[0]),
    rank: row[4] ?? 0,
    addTimestamp: row[5] ?? null,
  }));

  let past: PastGroupMember[] = [];
  if (tableExists('group_past_participant_user')) {
    const pastRows = tryQuery(`
      SELECT gppu.user_jid_row_id, j.user, j.raw_string, j.server, gppu.is_leave, gppu.timestamp
        ${mappedJidSelect}
      FROM group_past_participant_user gppu
      LEFT JOIN jid j ON j._id = gppu.user_jid_row_id
      ${mappedJidJoin}
      WHERE gppu.group_jid_row_id = ${chatJidRowId}
      ORDER BY gppu.timestamp DESC
    `) ?? [];
    past = pastRows.map((row: any[]) => ({
      jidRowId: row[0],
      phone: resolveJidPhone(row[1], row[2], row[3], row[6], row[7], row[8]) || String(row[1] ?? row[0]),
      leftVoluntarily: row[4] === 1,
      timestamp: row[5] ?? null,
    }));
  }

  return { current, past };
};

export const getDbInstance = () => dbInstance;
