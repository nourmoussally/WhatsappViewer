import { Conversation, Message } from '../types';

const escapeHtml = (value: string): string =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

const formatTimestamp = (date: Date): string =>
  date.toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

const formatDateHeader = (date: Date): string =>
  date.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });

const groupByDate = (messages: Message[]): Record<string, Message[]> => {
  const groups: Record<string, Message[]> = {};
  messages.forEach((m) => {
    const key = formatDateHeader(m.timestamp);
    if (!groups[key]) groups[key] = [];
    groups[key].push(m);
  });
  return groups;
};

const renderMessageContent = (m: Message): string => {
  if (m.system_kind === 'call' && m.call_info) {
    const kind = m.call_info.video ? 'Video call' : 'Voice call';
    const label = m.call_info.missed
      ? `Missed ${kind.toLowerCase()}`
      : m.call_info.duration > 0
        ? `${kind} (${Math.floor(m.call_info.duration / 60)}m ${m.call_info.duration % 60}s)`
        : kind;
    return `<div class="system-line">📞 ${escapeHtml(label)}</div>`;
  }
  if (m.system_kind === 'system_event') {
    const evt = m.system_event;
    let label = 'System update';
    switch (evt?.kind) {
      case 'group_participant':
        label = evt.personJid ? `Group membership update — ${evt.personJid}` : 'Group membership update';
        break;
      case 'group_self':
        label = 'Your membership in this group changed';
        break;
      case 'group_photo':
        label = 'The group photo was changed';
        break;
      case 'number_change':
        label = evt.oldValue && evt.newValue ? `Phone number changed: ${evt.oldValue} → ${evt.newValue}` : 'A phone number changed';
        break;
      case 'username_change':
        label = evt.oldValue && evt.newValue ? `Username changed: ${evt.oldValue} → ${evt.newValue}` : 'A username changed';
        break;
      case 'group_info_change':
        label = evt.oldValue ? `Group info updated (previously: "${evt.oldValue}")` : 'Group info was updated';
        break;
      case 'business_notice':
        label = 'Business/privacy notice';
        break;
      default:
        label = 'Group or system update — no further details are stored for this event in this backup';
    }
    return `<div class="system-line">ℹ️ ${escapeHtml(label)}</div>`;
  }
  if (m.system_kind === 'location' && m.location_info) {
    const { latitude, longitude, placeName } = m.location_info;
    const parts = [placeName ? escapeHtml(placeName) : null];
    if (latitude != null && longitude != null) {
      parts.push(`<a href="https://www.google.com/maps?q=${latitude},${longitude}">${latitude.toFixed(5)}, ${longitude.toFixed(5)}</a>`);
    }
    return `<div>📍 ${parts.filter(Boolean).join(' · ') || 'Location shared'}</div>`;
  }
  if (m.has_media) {
    const label = m.media_name || m.media_caption || 'Media file';
    const caption = m.media_caption && m.media_caption !== label
      ? `<div class="caption">${escapeHtml(m.media_caption)}</div>` : '';
    return `<div class="media-line">📎 <em>${escapeHtml(label)}</em></div>${caption}`;
  }
  if (m.text_data) {
    return `<div>${escapeHtml(m.text_data).replace(/\n/g, '<br/>')}</div>`;
  }
  return `<div class="system-line">(no content)</div>`;
};

export const buildConversationHtml = (conversation: Conversation, messages: Message[]): string => {
  const title = conversation.subject || conversation.contactName || conversation.phone || 'Conversation';
  const groups = groupByDate(messages);

  const body = Object.entries(groups).map(([dateLabel, msgs]) => {
    const rows = msgs.map((m) => {
      if (m.system_kind === 'call' || m.system_kind === 'system_event') {
        return `<div class="system-row">${renderMessageContent(m)}</div>`;
      }
      const align = m.from_me ? 'sent' : 'received';
      return `
        <div class="bubble-row ${align}">
          <div class="bubble ${align}">
            ${m.quoted_text ? `<div class="quote">${escapeHtml(m.quoted_text)}</div>` : ''}
            ${renderMessageContent(m)}
            <div class="meta">${formatTimestamp(m.timestamp)}</div>
          </div>
        </div>`;
    }).join('\n');
    return `<div class="date-header"><span>${escapeHtml(dateLabel)}</span></div>${rows}`;
  }).join('\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>${escapeHtml(title)} — WhatsApp Export</title>
<style>
  * { box-sizing: border-box; }
  body {
    font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    background: #e5ddd5;
    margin: 0;
    padding: 24px;
    color: #111;
  }
  .header {
    max-width: 640px;
    margin: 0 auto 16px;
    background: #008069;
    color: white;
    padding: 14px 18px;
    border-radius: 10px 10px 0 0;
    font-size: 18px;
    font-weight: 600;
  }
  .thread {
    max-width: 640px;
    margin: 0 auto;
    background: #e5ddd5;
    padding: 12px 18px 24px;
    border-radius: 0 0 10px 10px;
  }
  .date-header {
    text-align: center;
    margin: 16px 0 8px;
  }
  .date-header span {
    background: #e1f2fb;
    color: #54656f;
    font-size: 12px;
    padding: 4px 10px;
    border-radius: 6px;
  }
  .system-row { text-align: center; margin: 8px 0; }
  .system-line, .system-row {
    color: #54656f;
    font-size: 12px;
  }
  .bubble-row { display: flex; margin: 3px 0; }
  .bubble-row.sent { justify-content: flex-end; }
  .bubble-row.received { justify-content: flex-start; }
  .bubble {
    max-width: 75%;
    padding: 6px 9px 4px;
    border-radius: 8px;
    font-size: 14px;
    line-height: 1.4;
    box-shadow: 0 1px 0.5px rgba(0,0,0,0.13);
  }
  .bubble.sent { background: #d9fdd3; border-top-right-radius: 0; }
  .bubble.received { background: #fff; border-top-left-radius: 0; }
  .quote {
    background: rgba(0,0,0,0.05);
    border-left: 3px solid #06cf9c;
    padding: 4px 6px;
    margin-bottom: 4px;
    font-size: 12.5px;
    color: #555;
    border-radius: 4px;
  }
  .caption { font-size: 12.5px; color: #555; margin-top: 2px; }
  .media-line { font-size: 13.5px; }
  .meta {
    font-size: 10.5px;
    color: #667781;
    text-align: right;
    margin-top: 2px;
  }
  @media print {
    body { background: white; padding: 0; }
    .thread { background: white; }
    .bubble.sent { background: #eafce6; }
  }
</style>
</head>
<body>
  <div class="header">${escapeHtml(title)}</div>
  <div class="thread">
    ${body || '<p style="text-align:center;color:#999;">No messages to display.</p>'}
  </div>
</body>
</html>`;
};

export const downloadConversationHtml = (conversation: Conversation, messages: Message[]): void => {
  const html = buildConversationHtml(conversation, messages);
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const safeName = (conversation.subject || conversation.contactName || conversation.phone || 'conversation')
    .replace(/[^a-z0-9]+/gi, '_')
    .slice(0, 60);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${safeName || 'conversation'}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
};

/** Opens the conversation in a new tab and triggers the browser's print
 *  dialog, where the user can choose "Save as PDF" — no PDF library
 *  needed, and it works consistently across browsers. */
export const printConversationAsPdf = (conversation: Conversation, messages: Message[]): void => {
  const html = buildConversationHtml(conversation, messages);
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.onload = () => {
    printWindow.focus();
    printWindow.print();
  };
};
