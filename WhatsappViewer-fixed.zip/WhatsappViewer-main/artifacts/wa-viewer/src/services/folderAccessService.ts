// Persists access to the user's WhatsApp Media folder across sessions
// using the File System Access API (Chrome/Edge only). Firefox and Safari
// don't support this API, so on those browsers the app falls back to the
// classic <input webkitdirectory> picker with no persistence — this is a
// hard browser limitation, not something we can work around.

const DB_NAME = 'wa-viewer-folder-access';
const STORE_NAME = 'handles';
const HANDLE_KEY = 'media-folder';

export const isFileSystemAccessSupported = (): boolean =>
  typeof window !== 'undefined' && 'showDirectoryPicker' in window;

const openIndexedDb = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

export const saveDirectoryHandle = async (handle: FileSystemDirectoryHandle): Promise<void> => {
  const db = await openIndexedDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(handle, HANDLE_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
};

export const loadSavedDirectoryHandle = async (): Promise<FileSystemDirectoryHandle | null> => {
  try {
    const db = await openIndexedDb();
    const handle = await new Promise<FileSystemDirectoryHandle | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(HANDLE_KEY);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return handle;
  } catch {
    return null;
  }
};

export const forgetSavedDirectoryHandle = async (): Promise<void> => {
  try {
    const db = await openIndexedDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(HANDLE_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Nothing to forget — fine either way.
  }
};

/** Checks current permission state without prompting the user. */
export const hasReadPermission = async (handle: FileSystemDirectoryHandle): Promise<boolean> => {
  try {
    const status = await (handle as any).queryPermission?.({ mode: 'read' });
    return status === 'granted';
  } catch {
    return false;
  }
};

/** Requests permission — must be called from a user gesture (e.g. a click). */
export const requestReadPermission = async (handle: FileSystemDirectoryHandle): Promise<boolean> => {
  try {
    const status = await (handle as any).requestPermission?.({ mode: 'read' });
    return status === 'granted';
  } catch {
    return false;
  }
};

export interface CollectedFiles {
  files: Record<string, File>;
  count: number;
}

/** Recursively walks a directory handle and builds the same lookup index
 *  used by the manual <input webkitdirectory> flow: by filename, by full
 *  relative path, and by base name (without extension) for fallback
 *  matching when the stored extension doesn't match the real file. */
export const collectFilesFromDirectory = async (
  root: FileSystemDirectoryHandle,
): Promise<CollectedFiles> => {
  const nextFiles: Record<string, File> = {};
  let count = 0;

  const walk = async (dirHandle: FileSystemDirectoryHandle, pathPrefix: string) => {
    for await (const [name, handle] of (dirHandle as any).entries()) {
      const relativePath = pathPrefix ? `${pathPrefix}/${name}` : name;
      if (handle.kind === 'file') {
        const file: File = await (handle as FileSystemFileHandle).getFile();
        count += 1;
        const lowerName = file.name.toLowerCase();
        nextFiles[lowerName] = file;
        const normalizedPath = relativePath.toLowerCase();
        nextFiles[normalizedPath] = file;
        const baseName = lowerName.replace(/\.[^./\\]+$/, '');
        if (baseName && !nextFiles[`base:${baseName}`]) {
          nextFiles[`base:${baseName}`] = file;
        }
      } else if (handle.kind === 'directory') {
        await walk(handle as FileSystemDirectoryHandle, relativePath);
      }
    }
  };

  await walk(root, '');
  return { files: nextFiles, count };
};
