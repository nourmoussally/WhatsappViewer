export type EncryptionType = 'crypt12' | 'crypt14' | 'crypt15';

export const detectEncryptionType = (buffer: ArrayBuffer, fileName?: string): EncryptionType | null => {
  if (fileName) {
    if (fileName.endsWith('.crypt12')) return 'crypt12';
    if (fileName.endsWith('.crypt14')) return 'crypt14';
    if (fileName.endsWith('.crypt15')) return 'crypt15';
  }
  return null;
};

export const extractKey = async (keyFileBuffer: ArrayBuffer): Promise<{ cryptoKey: CryptoKey, raw: Uint8Array }> => {
  let keyData: Uint8Array<ArrayBuffer>;

  if (keyFileBuffer.byteLength === 32) {
    keyData = new Uint8Array(keyFileBuffer);
  } else if (keyFileBuffer.byteLength === 158) {
    keyData = new Uint8Array(keyFileBuffer.slice(126, 126 + 32));
  } else {
    try {
      const text = new TextDecoder().decode(keyFileBuffer).trim();
      if (text.length === 64 && /^[0-9a-fA-F]+$/.test(text)) {
        const matches = text.match(/.{1,2}/g);
        if (matches) {
          keyData = new Uint8Array(matches.map((b: string) => parseInt(b, 16)));
        } else {
          throw new Error("Invalid hex");
        }
      } else {
        const view = new DataView(keyFileBuffer);
        if (view.byteLength > 4 && view.getUint32(0) === 0xaced0005) {
          if (keyFileBuffer.byteLength === 59) {
            keyData = new Uint8Array(keyFileBuffer.slice(27, 59));
          } else {
            let keyStart = -1;
            const uint8 = new Uint8Array(keyFileBuffer);
            for (let i = 0; i <= uint8.length - 36; i++) {
              if (uint8[i] === 0 && uint8[i + 1] === 0 && uint8[i + 2] === 0 && uint8[i + 3] === 32) {
                keyStart = i + 4;
                break;
              }
            }
            if (keyStart !== -1) {
              keyData = new Uint8Array(keyFileBuffer.slice(keyStart, keyStart + 32));
            } else {
              if (keyFileBuffer.byteLength >= 32) {
                keyData = new Uint8Array(keyFileBuffer.slice(keyFileBuffer.byteLength - 32));
              } else {
                throw new Error("Key file too small");
              }
            }
          }
        } else {
          throw new Error("Unknown key format");
        }
      }
    } catch (e) {
      throw new Error("Failed to parse key file");
    }
  }

  const cryptoKey = await window.crypto.subtle.importKey(
    'raw',
    keyData!,
    'AES-GCM',
    true,
    ['decrypt']
  );

  return { cryptoKey, raw: keyData! };
};

export const decryptDatabase = (
  encryptedBuffer: ArrayBuffer,
  key: CryptoKey,
  type: EncryptionType,
  rawKeyBytes?: Uint8Array,
  onProgress?: (status: string) => void
): Promise<ArrayBuffer> => {
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL('../workers/decryption.worker.ts', import.meta.url), { type: 'module' });

    worker.onmessage = (e) => {
      const { type: msgType, status, buffer, message } = e.data;
      if (msgType === 'progress') {
        if (onProgress) onProgress(status);
      } else if (msgType === 'complete') {
        resolve(buffer);
        worker.terminate();
      } else if (msgType === 'error') {
        reject(new Error(message));
        worker.terminate();
      }
    };

    worker.onerror = (err) => {
      reject(new Error("Worker Error: " + err.message));
      worker.terminate();
    };

    worker.postMessage({
      fileBuffer: encryptedBuffer,
      keyBuffer: null,
      encryptionType: type,
      rawKeyBytes: rawKeyBytes
    }, [encryptedBuffer]);
  });
};
