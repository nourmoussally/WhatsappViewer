export type ContactMap = Record<string, string>;

export interface ContactImportResult {
  contacts: ContactMap;
  count: number;
}

/** Keep only the digits used to match international phone numbers. */
export const normalizePhone = (value: string): string => {
  const digits = value.replace(/\D/g, '');
  return digits.startsWith('00') ? digits.slice(2) : digits;
};

const cleanVCardValue = (value: string): string =>
  value
    .replace(/\\n/gi, ' ')
    .replace(/\\,/g, ',')
    .replace(/\\;/g, ';')
    .replace(/\\\\/g, '\\')
    .trim();

const decodeQuotedPrintable = (value: string): string => {
  const bytes: number[] = [];
  for (let i = 0; i < value.length; i += 1) {
    if (value[i] === '=' && /^[0-9A-Fa-f]{2}$/.test(value.slice(i + 1, i + 3))) {
      bytes.push(parseInt(value.slice(i + 1, i + 3), 16));
      i += 2;
    } else {
      bytes.push(value.charCodeAt(i) & 0xff);
    }
  }
  return new TextDecoder('utf-8').decode(new Uint8Array(bytes));
};

const decodeVCardValue = (value: string, line: string): string => {
  const decoded = /ENCODING\s*=\s*QUOTED-PRINTABLE/i.test(line)
    ? decodeQuotedPrintable(value)
    : value;
  return cleanVCardValue(decoded);
};

const addContact = (contacts: ContactMap, name: string, phone: string) => {
  const normalizedPhone = normalizePhone(phone);
  const cleanName = cleanVCardValue(name);
  if (normalizedPhone.length >= 7 && cleanName) {
    contacts[normalizedPhone] = cleanName;
  }
};

const parseVCard = (text: string): ContactMap => {
  const contacts: ContactMap = {};
  // vCard allows a long property to continue on a line beginning with space/tab.
  const unfolded = text.replace(/\r?\n[ \t]/g, '');
  const cards = unfolded.split(/BEGIN:VCARD/i).slice(1);

  for (const card of cards) {
    const end = card.split(/END:VCARD/i)[0];
    // Quoted-printable values may use '=' as a soft line break.
    const unfoldedEnd = end.replace(/=\r?\n/g, '');
    const lines = unfoldedEnd.split(/\r?\n/);
    let name = '';
    const phones: string[] = [];

    for (const line of lines) {
      const nameMatch = line.match(/^(?:item\d+\.)?FN(?:;[^:]*)?:(.*)$/i);
      const nMatch = line.match(/^(?:item\d+\.)?N(?:;[^:]*)?:(.*)$/i);
      const phoneMatch = line.match(/^(?:item\d+\.)?TEL(?:;[^:]*)?:(.*)$/i);
      if (nameMatch) name = decodeVCardValue(nameMatch[1], line);
      else if (!name && nMatch) {
        const parts = nMatch[1].split(';')
          .map((part) => decodeVCardValue(part, line))
          .filter(Boolean);
        name = parts.reverse().join(' ').trim();
      } else if (phoneMatch) {
        phones.push(decodeVCardValue(phoneMatch[1], line));
      }
    }

    phones.forEach((phone) => addContact(contacts, name, phone));
  }

  return contacts;
};

const parseDelimitedRows = (text: string, delimiter: string): string[][] => {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (char === '"') {
      if (quoted && text[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === delimiter && !quoted) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }

  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
};

const headerIndex = (headers: string[], terms: string[]): number =>
  headers.findIndex((header) => {
    const normalized = header.toLowerCase().replace(/[\s_-]/g, '');
    return terms.some((term) => normalized.includes(term));
  });

const parseCsv = (text: string): ContactMap => {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? '';
  const delimiter = firstLine.includes(';') && !firstLine.includes(',')
    ? ';'
    : ',';
  const rows = parseDelimitedRows(text.replace(/^\uFEFF/, ''), delimiter);
  if (rows.length === 0) return {};

  const normalizedHeaders = rows[0].map((cell) => cell.toLowerCase().replace(/[\s_-]/g, ''));
  const nameIndex = headerIndex(normalizedHeaders, ['name', 'fullname', 'displayname', 'contact']);
  const phoneIndex = headerIndex(normalizedHeaders, ['phone', 'mobile', 'telephone', 'tel', 'number']);
  const hasHeader = nameIndex >= 0 || phoneIndex >= 0;
  const start = hasHeader ? 1 : 0;
  const contacts: ContactMap = {};

  for (const row of rows.slice(start)) {
    const name = row[hasHeader ? (nameIndex >= 0 ? nameIndex : 0) : 0] ?? '';
    const phone = row[hasHeader ? (phoneIndex >= 0 ? phoneIndex : 1) : 1] ?? '';
    addContact(contacts, name, phone);
  }

  return contacts;
};

export const parseContactsFile = (text: string, fileName: string): ContactImportResult => {
  const isVCard = /\.vcf$/i.test(fileName) || /BEGIN:VCARD/i.test(text);
  const contacts = isVCard ? parseVCard(text) : parseCsv(text);
  return { contacts, count: Object.keys(contacts).length };
};