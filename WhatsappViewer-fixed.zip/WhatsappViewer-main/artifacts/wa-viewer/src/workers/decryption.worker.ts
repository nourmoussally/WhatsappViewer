import * as pako from 'pako';
import forge from 'node-forge';

type EncryptionType = 'crypt12' | 'crypt14' | 'crypt15';

interface EncryptionParams {
  ivOffset: number;
  ivLength: number;
  dbStartOffset: number;
}

const CRYPT_CONFIG: Record<EncryptionType, EncryptionParams> = {
  'crypt12': { ivOffset: 51, ivLength: 16, dbStartOffset: 67 },
  'crypt14': { ivOffset: 67, ivLength: 16, dbStartOffset: 190 },
  'crypt15': { ivOffset: 8, ivLength: 16, dbStartOffset: 122 }
};

const toBinaryString = (bytes: Uint8Array): string => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return binary;
};

const deriveCrypt15Key = (rootKey: Uint8Array): Uint8Array => {
  const nullSeed = new Uint8Array(32);
  const hmacA = forge.hmac.create();
  hmacA.start('sha256', toBinaryString(nullSeed));
  hmacA.update(toBinaryString(rootKey));
  const privateKey = hmacA.digest().getBytes();
  const message = "backup encryption";
  const suffix = String.fromCharCode(0x01);
  const hmacB = forge.hmac.create();
  hmacB.start('sha256', privateKey);
  hmacB.update(message + suffix);
  const finalKey = hmacB.digest().getBytes();
  const arr = new Uint8Array(finalKey.length);
  for (let i = 0; i < finalKey.length; i++) arr[i] = finalKey.charCodeAt(i);
  return arr;
};

self.onmessage = async (e: MessageEvent) => {
  const { fileBuffer, encryptionType, rawKeyBytes } = e.data;
  const type = encryptionType as EncryptionType;

  try {
    self.postMessage({ type: 'progress', status: 'Deriving keys...' });

    let workingKeyBytes: string;
    if (type === 'crypt15') {
      if (!rawKeyBytes) throw new Error("Crypt15 requires raw key bytes for derivation");
      const derivedKey = deriveCrypt15Key(rawKeyBytes);
      workingKeyBytes = toBinaryString(derivedKey);
    } else {
      if (rawKeyBytes) {
        workingKeyBytes = toBinaryString(rawKeyBytes);
      } else {
        throw new Error("Raw key bytes required for worker");
      }
    }

    self.postMessage({ type: 'progress', status: 'Parsing file structure...' });

    const config = CRYPT_CONFIG[type];
    const view = new Uint8Array(fileBuffer);

    let iv: string;
    let ciphertext: Uint8Array;

    if (type === 'crypt15') {
      const viewData = new DataView(fileBuffer);
      let offset = 0;
      const protobufSize = viewData.getUint8(offset);
      offset++;
      const flagByte = viewData.getUint8(offset);
      if (flagByte === 1) offset++;
      const protobufStart = offset;
      const protobufEnd = offset + protobufSize;
      const protobufBuffer = new Uint8Array(fileBuffer).slice(protobufStart, protobufEnd);

      let pbOffset = 0;
      const pbView = new DataView(protobufBuffer.buffer);
      let foundIV: Uint8Array | null = null;

      const readVarint = () => {
        let tag = 0, shift = 0;
        while (true) {
          if (pbOffset >= protobufBuffer.byteLength) throw new Error("EOF");
          const b = pbView.getUint8(pbOffset++);
          tag |= (b & 0x7F) << shift;
          if ((b & 0x80) === 0) break;
          shift += 7;
        }
        return tag;
      };

      try {
        while (pbOffset < protobufBuffer.byteLength) {
          const tag = readVarint();
          const wireType = tag & 0x07;
          const fieldNum = tag >>> 3;
          if (wireType === 2) {
            const len = readVarint();
            const payload = new Uint8Array(protobufBuffer.slice(pbOffset, pbOffset + len));
            if (fieldNum === 3) {
              let subOffset = 0;
              const subView = new DataView(payload.buffer);
              while (subOffset < payload.byteLength) {
                let sTag = 0, sShift = 0;
                while (true) {
                  const b = subView.getUint8(subOffset++);
                  sTag |= (b & 0x7F) << sShift;
                  if ((b & 0x80) === 0) break;
                  sShift += 7;
                }
                const sWire = sTag & 0x07;
                const sField = sTag >>> 3;
                if (sField === 1 && sWire === 2) {
                  let sLen = 0, slShift = 0;
                  while (true) {
                    const b = subView.getUint8(subOffset++);
                    sLen |= (b & 0x7F) << slShift;
                    if ((b & 0x80) === 0) break;
                    slShift += 7;
                  }
                  if (sLen === 16) foundIV = new Uint8Array(payload.slice(subOffset, subOffset + 16));
                  subOffset += sLen;
                } else if (sWire === 2) {
                  let sLen = 0, slShift = 0;
                  while (true) {
                    const b = subView.getUint8(subOffset++);
                    sLen |= (b & 0x7F) << slShift;
                    if ((b & 0x80) === 0) break;
                    slShift += 7;
                  }
                  subOffset += sLen;
                } else break;
              }
            }
            pbOffset += len;
          } else if (wireType === 0) { while ((pbView.getUint8(pbOffset++) & 0x80) !== 0); }
          else if (wireType === 1) pbOffset += 8;
          else if (wireType === 5) pbOffset += 4;
          else break;
        }
      } catch (_) {}

      iv = foundIV ? toBinaryString(foundIV) : toBinaryString(view.slice(8, 24));
      const tagStart = view.byteLength - 32;
      ciphertext = view.slice(protobufEnd, tagStart);
      const tagBytes = view.slice(tagStart, view.byteLength - 16);

      self.postMessage({ type: 'progress', status: 'Decrypting AES-GCM...' });

      const decipher = forge.cipher.createDecipher('AES-GCM', workingKeyBytes);
      // Copy the typed-array slices into exact ArrayBuffers. Newer TypeScript
      // versions type Uint8Array.buffer as ArrayBufferLike, while forge needs
      // an ArrayBuffer and the original slices may have a non-zero offset.
      const tagBuffer = tagBytes.slice().buffer as ArrayBuffer;
      const ciphertextBuffer = ciphertext.slice().buffer as ArrayBuffer;
      decipher.start({ iv, tag: forge.util.createBuffer(tagBuffer), tagLength: 128 });
      decipher.update(forge.util.createBuffer(ciphertextBuffer));
      if (!decipher.finish()) throw new Error("Decryption failed (Auth Mismatch)");

      const decryptedBytes = decipher.output.getBytes();
      const arr = new Uint8Array(decryptedBytes.length);
      for (let i = 0; i < decryptedBytes.length; i++) arr[i] = decryptedBytes.charCodeAt(i);

      self.postMessage({ type: 'progress', status: 'Decompressing Zlib...' });

      try {
        const inflated = pako.inflate(arr).buffer;
        self.postMessage({ type: 'complete', buffer: inflated }, { transfer: [inflated] });
      } catch (_) {
        throw new Error("Decompression failed (Invalid Zlib data)");
      }
    } else {
      self.postMessage({ type: 'progress', status: 'Decrypting Legacy Format...' });
      const rawIv = view.slice(config.ivOffset, config.ivOffset + config.ivLength);
      iv = toBinaryString(rawIv);
      ciphertext = type === 'crypt14' ? view.slice(config.dbStartOffset) : view.slice(config.dbStartOffset, view.length - 20);

      const decipher = forge.cipher.createDecipher('AES-GCM', workingKeyBytes);
      decipher.start({ iv });
      const ciphertextBuffer = ciphertext.slice().buffer as ArrayBuffer;
      decipher.update(forge.util.createBuffer(ciphertextBuffer));
      decipher.finish();

      const decryptedBytes = decipher.output.getBytes();
      const arr = new Uint8Array(decryptedBytes.length);
      for (let i = 0; i < decryptedBytes.length; i++) arr[i] = decryptedBytes.charCodeAt(i);

      self.postMessage({ type: 'progress', status: 'Decompressing (Legacy)...' });

      try {
        const inflated = pako.inflate(arr).buffer;
        self.postMessage({ type: 'complete', buffer: inflated }, { transfer: [inflated] });
      } catch (_) {
        self.postMessage({ type: 'complete', buffer: arr.buffer }, { transfer: [arr.buffer] });
      }
    }
  } catch (error: any) {
    self.postMessage({ type: 'error', message: error.message || "Unknown worker error" });
  }
};
