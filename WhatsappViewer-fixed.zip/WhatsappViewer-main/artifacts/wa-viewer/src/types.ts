export interface Conversation {
  _id: number;
  /** jid._id row referenced by chat.jid_row_id — needed to look up group
   *  members, which key off the group's own jid row, not chat._id. */
  jid_row_id: number;
  jid: string;
  phone: string;
  contactName?: string;
  subject: string | null;
  timestamp: number;
  messageCount?: number;
  /** Disappearing-messages timer in seconds (0/undefined = off). WhatsApp
   *  only ever uses 86400 (24h), 604800 (7 days), or 7776000 (90 days). */
  ephemeralExpiration?: number;
}

export interface CallInfo {
  video: boolean;
  duration: number;
  missed: boolean;
}

export interface LocationInfo {
  latitude: number | null;
  longitude: number | null;
  placeName: string | null;
}

export interface ContactInfo {
  name: string | null;
  phone: string | null;
}

export interface AlbumInfo {
  imageCount: number;
  videoCount: number;
}

export type SystemKind = 'call' | 'location' | 'album' | 'system_event';

/**
 * Sub-classification for `system_kind === 'system_event'`, resolved from
 * whichever message_system_* subtype table matched (see dbService).
 * `other` means it's confirmed to be a system event (message_system row
 * exists) but none of the specifically-decoded subtypes matched — real
 * data showed this covers only ~4% of system events.
 */
export type SystemEventKind =
  | 'group_participant'
  | 'group_self'
  | 'group_photo'
  | 'number_change'
  | 'username_change'
  | 'group_info_change'
  | 'business_notice'
  | 'other';

export interface SystemEventInfo {
  kind: SystemEventKind;
  /** Resolved identifier (phone number if resolvable, otherwise a raw
   *  local jid part) of the participant this event is about — only for
   *  'group_participant'. */
  personJid?: string | null;
  /** Old/new value pair — meaning depends on `kind`:
   *  'number_change': old/new phone-ish identifier.
   *  'username_change': old/new username (literal text from the DB).
   *  'group_info_change': old value only (new value isn't stored). */
  oldValue?: string | null;
  newValue?: string | null;
}

export type ReceiptStatus = 'sent' | 'delivered' | 'read';

export interface MessageReaction {
  emoji: string;
  fromMe: boolean;
  /** Resolved phone number of the reactor in a group chat; null for the
   *  local user's own reaction or a 1:1 chat (where the other side is
   *  already identified by the conversation itself). */
  senderPhone: string | null;
}

export interface Message {
  _id: number;
  from_me: boolean;
  text_data: string | null;
  timestamp: Date;
  quoted_text: string | null;
  has_media: boolean;
  media_wa_type?: number;
  media_name?: string | null;
  /** An alternate candidate filename for this media, when the database
   *  stores two differently-named references to it (commonly `file_path`
   *  vs `media_name` — one is usually the real local filename and the
   *  other an internal hash-style id). Tried as a second option when
   *  matching against the selected media folder fails with media_name. */
  media_alt_name?: string | null;
  /** False when media_name was synthesized from a CDN path / mime type
   *  fallback rather than a real filename stored in the database — such
   *  names cannot be reliably matched to a local file. */
  media_name_reliable?: boolean;
  /** True when the database never recorded any local filename at all for
   *  this media (both file_path and media_name were empty) — meaning
   *  WhatsApp itself never saved a local copy, most commonly because it
   *  was never downloaded/opened. No folder selection can ever locate
   *  this file, as distinct from media_name_reliable=false cases where a
   *  name exists but is untrustworthy for matching. */
  media_never_downloaded?: boolean;
  media_size?: number | null;
  media_caption?: string | null;
  media_duration?: number | null;
  media_mime_type?: string | null;
  media_direct_path?: string | null;
  media_key?: Uint8Array | number[] | ArrayBuffer | null;
  /** Only meaningful for messages sent by the user (from_me). Derived from
   *  receipt_user rows: 'read' when every recipient has a read receipt,
   *  'delivered' when at least one recipient received it but not all read
   *  it yet, otherwise 'sent'. */
  receipt_status?: ReceiptStatus;
  /** True when this message was deleted (revoked) by the sender — its
   *  original content is gone from the backup entirely. */
  is_revoked?: boolean;
  /** True when the message was edited after being sent. text_data already
   *  reflects the latest (edited) content. */
  is_edited?: boolean;
  edited_timestamp?: Date;
  /** True when this message was forwarded from elsewhere (not authored
   *  fresh in this chat). */
  is_forwarded?: boolean;
  /** True when forwarded 5+ times — WhatsApp shows a distinct
   *  "forwarded many times" double-arrow icon for these. */
  forwarded_many_times?: boolean;
  system_kind?: SystemKind;
  system_event?: SystemEventInfo;
  call_info?: CallInfo;
  location_info?: LocationInfo;
  album_info?: AlbumInfo;
  contact_info?: ContactInfo;
  reactions?: MessageReaction[];
  /** Formatted phone number (e.g. "+123...") of who sent this message in a
   *  group chat. Only meaningful when from_me is false and the chat is a
   *  group; null/undefined for 1:1 chats or when it can't be resolved. */
  sender_phone?: string | null;
}

export interface DbStats {
  chatCount: number;
  messageCount: number;
}
