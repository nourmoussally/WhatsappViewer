import React, { useEffect, useRef, useState } from 'react';
import { Message } from '../types';
import { Check, Image as ImageIcon, Video, Music, FileText, MapPin, Phone, PhoneMissed, Sticker, File, Download, Loader, Upload, Ban, Forward, Users, Shield } from 'lucide-react';
import { formatFileSize, getMediaLabel } from '../services/dbService';
import { downloadSticker } from '../services/stickerService';

interface MessageBubbleProps {
  message: Message;
  localMediaFile?: File;
  /** Called when the user manually picks a file to use for this message
   *  (e.g. when the on-disk file was renamed and auto-matching failed). */
  onManualFileSelect?: (messageId: number, file: File) => void;
  /** Display name/phone of who sent this message — shown at the top of
   *  the bubble for incoming group messages, WhatsApp-style. */
  senderLabel?: string;
  senderColor?: string;
  /** Emoji reactions on this message, already grouped by emoji with a
   *  count and a "who reacted" tooltip — see ChatWindow's
   *  summarizeReactions. */
  reactions?: { emoji: string; count: number; title: string }[];
}

// Sticker type codes across WhatsApp schema versions: 16 = classic
// (`media_wa_type` column present), 20 = modern (`message_type` fallback).
export const STICKER_TYPES = new Set([16, 20]);
export const VIDEO_TYPES = new Set([3, 13, 14, 28, 43, 62, 81]);
export const AUDIO_TYPES = new Set([2, 9, 26, 82]);

const getMediaIcon = (waType: number | null | undefined) => {
  if (waType != null && STICKER_TYPES.has(waType)) {
    return <Sticker size={18} className="flex-shrink-0" />;
  }
  if (waType != null && AUDIO_TYPES.has(waType)) {
    return <Music size={18} className="flex-shrink-0" />;
  }
  if (waType != null && VIDEO_TYPES.has(waType)) {
    return <Video size={18} className="flex-shrink-0" />;
  }
  switch (waType) {
    case 1: return <ImageIcon size={18} className="flex-shrink-0" />;
    case 4: return <Phone size={18} className="flex-shrink-0" />;
    case 5: return <MapPin size={18} className="flex-shrink-0" />;
    case 8: return <FileText size={18} className="flex-shrink-0" />;
    default: return <File size={18} className="flex-shrink-0" />;
  }
};

const getMediaColor = (waType: number | null | undefined, isSent: boolean) => {
  const base = isSent ? 'bg-green-200/60' : 'bg-gray-100';
  if (waType != null && AUDIO_TYPES.has(waType)) {
    return isSent ? 'bg-purple-100/80 text-purple-700' : 'bg-purple-50 text-purple-700';
  }
  if (waType != null && VIDEO_TYPES.has(waType)) {
    return isSent ? 'bg-red-100/80 text-red-700' : 'bg-red-50 text-red-700';
  }
  switch (waType) {
    case 1: return isSent ? 'bg-blue-100/80 text-blue-700' : 'bg-blue-50 text-blue-700';
    case 4: return isSent ? 'bg-yellow-100/80 text-yellow-700' : 'bg-yellow-50 text-yellow-700';
    case 5: return isSent ? 'bg-teal-100/80 text-teal-700' : 'bg-teal-50 text-teal-700';
    case 8: return isSent ? 'bg-orange-100/80 text-orange-700' : 'bg-orange-50 text-orange-700';
    default: return `${base} text-gray-600`;
  }
};

const formatDuration = (seconds: number | null | undefined): string => {
  if (!seconds) return '';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const getMediaKind = (
  mimeType: string,
  fileName: string | null,
  waType: number | null | undefined,
): 'image' | 'video' | 'audio' | null => {
  const mime = mimeType.split(';')[0].trim().toLowerCase();
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('video/')) return 'video';
  if (mime.startsWith('audio/')) return 'audio';

  const extension = fileName?.split('.').pop()?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'avif'].includes(extension || '')) return 'image';
  if (['mp4', '3gp', 'mov', 'webm', 'mkv'].includes(extension || '')) return 'video';
  if (['ogg', 'opus', 'mp3', 'm4a', 'aac', 'wav', 'amr'].includes(extension || '')) return 'audio';

  if (waType != null && STICKER_TYPES.has(waType)) return 'image';
  if (waType === 1) return 'image';
  if (waType != null && AUDIO_TYPES.has(waType)) return 'audio';
  if (waType != null && VIDEO_TYPES.has(waType)) return 'video';
  return null;
};

// Genuine Safari detection (Safari's UA string includes "Safari", but so
// do Chrome/Edge/Firefox-based browsers for legacy compatibility — has to
// be excluded explicitly, or every Chromium browser gets misdiagnosed as
// Safari here).
const isRealSafari = (): boolean => {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent;
  return /^((?!chrome|chromium|crios|fxios|edg|opr\/).)*safari/i.test(ua);
};

const getPreviewMimeType = (file: File, fallbackMime: string): string => {
  const declaredMime = (file.type || fallbackMime).split(';')[0].trim().toLowerCase();
  if (declaredMime.startsWith('audio/')) return declaredMime;

  const extension = file.name.split('.').pop()?.toLowerCase();
  const audioTypes: Record<string, string> = {
    opus: 'audio/ogg',
    ogg: 'audio/ogg',
    oga: 'audio/ogg',
    mp3: 'audio/mpeg',
    m4a: 'audio/mp4',
    aac: 'audio/aac',
    wav: 'audio/wav',
    amr: 'audio/amr',
  };
  return audioTypes[extension || ''] || declaredMime || 'application/octet-stream';
};

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, localMediaFile, onManualFileSelect, senderLabel, senderColor, reactions }) => {
  const isSent = message.from_me;
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const localPreviewFile = localMediaFile;

  // Lazy-load media: browsers cap how many <audio>/<video> elements can be
  // actively decoding at once. Long chats can have thousands of voice
  // notes, and eagerly mounting a real <audio> tag for every single one
  // on initial render exhausts that limit — some end up firing a bogus
  // "corrupted/unsupported" error even though the file is completely
  // fine (confirmed: leaving and reopening the chat always fixes it,
  // since that frees up the previous batch of decoders). Only create the
  // blob URL / mount the real media element once this bubble has
  // scrolled near the viewport.
  const bubbleRef = useRef<HTMLDivElement>(null);
  const [isNearViewport, setIsNearViewport] = useState(false);

  useEffect(() => {
    if (isNearViewport || !bubbleRef.current) return;
    const el = bubbleRef.current;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setIsNearViewport(true);
          observer.disconnect();
        }
      },
      { rootMargin: '600px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [isNearViewport]);

  useEffect(() => {
    if (!localPreviewFile || !isNearViewport) {
      setMediaUrl(null);
      setMediaError(null);
      return;
    }
    setMediaError(null);
    const previewBlob = new Blob(
      [localPreviewFile],
      { type: getPreviewMimeType(localPreviewFile, message.media_mime_type || '') },
    );
    const url = URL.createObjectURL(previewBlob);
    setMediaUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [localPreviewFile, message.media_mime_type, isNearViewport]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMediaContent = () => {
    const label = getMediaLabel(message.media_wa_type);
    const icon = getMediaIcon(message.media_wa_type);
    const colorClass = getMediaColor(message.media_wa_type, isSent);
    const fileName = message.media_name;
    const fileSize = formatFileSize(message.media_size);
    const duration = formatDuration(message.media_duration);
    const isSticker = message.media_wa_type != null && STICKER_TYPES.has(message.media_wa_type);
    const mimeType = (localPreviewFile?.type || message.media_mime_type || '').toLowerCase();
    const mediaKind = getMediaKind(mimeType, fileName ?? null, message.media_wa_type);
    const resolvedAudioMime = localPreviewFile
      ? getPreviewMimeType(localPreviewFile, message.media_mime_type || '')
      : mimeType;
    const isAmrAudio = mediaKind === 'audio'
      && (resolvedAudioMime === 'audio/amr' || (fileName || '').toLowerCase().endsWith('.amr'));
    const isOggAudio = mediaKind === 'audio' && resolvedAudioMime === 'audio/ogg';
    const canDownloadSticker = isSticker && (
      !!localMediaFile || (!!message.media_direct_path && !!message.media_key)
    );

    const handleStickerDownload = async () => {
      setIsDownloading(true);
      setDownloadError(null);
      try {
         await downloadSticker(message, localMediaFile);
      } catch (error: any) {
        setDownloadError(error.message || 'Could not download this sticker.');
      } finally {
        setIsDownloading(false);
      }
    };

    return (
      <div className={`flex items-start gap-2 p-2 rounded-lg ${colorClass} mb-1 min-w-[140px]`}>
        <div className="mt-0.5">{icon}</div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-xs uppercase tracking-wide opacity-70 mb-0.5">{label}</div>
          {message.contact_info && (message.contact_info.name || message.contact_info.phone) ? (
            <>
              {message.contact_info.name && (
                <div className="text-sm font-medium truncate" title={message.contact_info.name}>
                  {message.contact_info.name}
                </div>
              )}
              {message.contact_info.phone && (
                <div className="text-xs opacity-70 font-mono truncate">
                  {message.contact_info.phone}
                </div>
              )}
            </>
          ) : message.media_never_downloaded ? (
            <div className="text-sm italic opacity-60">Not saved locally</div>
          ) : fileName && (
            <div className="text-sm font-medium truncate" title={fileName}>
              {fileName}
            </div>
          )}
          {mediaUrl && mediaKind === 'image' && (
            <img
              src={mediaUrl}
              alt={message.media_caption || fileName || 'WhatsApp image'}
              className={
                isSticker
                  ? 'mt-2 max-h-32 max-w-32 rounded-lg object-contain'
                  : 'mt-2 max-h-72 max-w-full rounded-lg object-contain'
              }
              loading="lazy"
            />
          )}
          {!mediaUrl && localMediaFile && !isSticker && mediaKind && (
            <div className="mt-2 h-10 w-full max-w-xs rounded bg-black/5 animate-pulse" />
          )}
          {mediaUrl && mediaKind === 'video' && (
            <video
              src={mediaUrl}
              controls
              preload="metadata"
              className="mt-2 max-h-72 max-w-full rounded-lg"
            />
          )}
          {mediaUrl && mediaKind === 'audio' && (
            <>
              {isAmrAudio ? (
                // No browser (Chrome, Firefox, or Safari) can decode AMR
                // natively — this isn't a bug to retry, playback here will
                // never work. Skip straight to a download fallback instead
                // of showing a broken player.
                <div className="mt-2 text-[11px] text-gray-500">
                  This voice note is in AMR format, which browsers can't play directly.
                </div>
              ) : (
                <audio
                  src={mediaUrl}
                  controls
                  preload="metadata"
                  className="mt-2 w-full max-w-xs"
                  onError={() => setMediaError(
                    isOggAudio && isRealSafari()
                      ? "This voice note's format isn't supported by Safari — try Chrome or Firefox, or download it below."
                      : "This audio file couldn't be played — it may be corrupted, incomplete, or an unsupported format. Try downloading it below to check it directly."
                  )}
                />
              )}
              {(isAmrAudio || mediaError) && (
                <a
                  href={mediaUrl}
                  download={fileName || 'audio'}
                  className="mt-1 inline-block text-[11px] text-[#008069] font-medium hover:underline"
                >
                  Download audio file
                </a>
              )}
            </>
          )}
          {mediaError && !isAmrAudio && (
            <div className="mt-1 text-[11px] text-red-600 break-words">
              {mediaError}
            </div>
          )}
          <div className="flex items-center gap-2 mt-0.5 text-xs opacity-60">
            {fileSize && <span>{fileSize}</span>}
            {duration && <span>{duration}</span>}
          </div>
          {message.media_caption && (
            <div className="mt-1 text-sm text-gray-700 whitespace-pre-wrap break-words" style={{ wordBreak: 'break-word' }}>
              {message.media_caption}
            </div>
          )}
          {isSticker && (
            <button
              type="button"
              onClick={handleStickerDownload}
              disabled={isDownloading || !canDownloadSticker}
              className="mt-2 inline-flex items-center gap-1 rounded bg-black/10 px-2 py-1 text-[11px] font-medium hover:bg-black/20 disabled:cursor-not-allowed disabled:opacity-50"
               title={localMediaFile
                ? 'Download sticker from the selected media folder'
                : canDownloadSticker
                  ? 'Download sticker from WhatsApp CDN'
                  : 'Select the WhatsApp Stickers folder first'}
            >
              {isDownloading ? <Loader size={12} className="animate-spin" /> : <Download size={12} />}
              {isDownloading ? 'Downloading...' : 'Download sticker'}
            </button>
          )}
          {localMediaFile && !isSticker && (
            <a
              href={mediaUrl || undefined}
              download={fileName || localMediaFile.name}
              className="mt-2 inline-flex items-center gap-1 rounded bg-black/10 px-2 py-1 text-[11px] font-medium hover:bg-black/20"
            >
              <Download size={12} />
              Download {label.toLowerCase()}
            </a>
          )}
          {!localMediaFile && !isSticker && mediaKind && (
            <div className="mt-2 text-[11px] opacity-60">
              {message.media_never_downloaded
                ? "WhatsApp never saved a local copy of this file on the device (only a server reference remains) — it can't be found in any folder, since it was likely never downloaded or was auto-deleted."
                : message.media_name_reliable === false
                ? "This file's original name isn't stored in the backup, so it can't be automatically matched — even with the right folder selected."
                : "Couldn't find this file automatically. It may exist under a different name."}
            </div>
          )}
          {!localMediaFile && !isSticker && mediaKind && onManualFileSelect && (
            <label className="mt-1 inline-flex items-center gap-1 rounded bg-black/10 px-2 py-1 text-[11px] font-medium hover:bg-black/20 cursor-pointer">
              <Upload size={12} />
              Attach file manually
              <input
                type="file"
                accept={
                  mediaKind === 'image' ? 'image/*'
                  : mediaKind === 'video' ? 'video/*'
                  : mediaKind === 'audio' ? 'audio/*'
                  : undefined
                }
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onManualFileSelect(message._id, file);
                  e.target.value = '';
                }}
                className="hidden"
              />
            </label>
          )}
          {downloadError && (
            <div className="mt-1 text-[11px] text-red-600 break-words">
              {downloadError}
            </div>
          )}
          {!fileName && !message.media_caption && !message.contact_info && (
            <div className="text-xs opacity-50 italic">No filename stored</div>
          )}
        </div>
      </div>
    );
  };

  const formatCallDuration = (seconds: number): string => {
    if (!seconds) return '';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
  };

  const renderCallMessage = () => {
    const info = message.call_info;
    if (!info) return null;
    const kindLabel = info.video ? 'Video call' : 'Voice call';
    const label = info.missed
      ? `Missed ${kindLabel.toLowerCase()}`
      : info.duration > 0
        ? `${kindLabel} · ${formatCallDuration(info.duration)}`
        : kindLabel;
    return (
      <div className="flex justify-center my-2 w-full">
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${
          info.missed ? 'bg-red-50 text-red-600' : 'bg-gray-100 text-gray-600'
        }`}>
          {info.missed ? <PhoneMissed size={14} /> : <Phone size={14} />}
          <span>{label}</span>
          <span className="opacity-50">{formatTime(message.timestamp)}</span>
        </div>
      </div>
    );
  };

  const renderSystemEventNotice = () => {
    const evt = message.system_event;
    let icon = <Shield size={12} className="flex-shrink-0" />;
    let text: React.ReactNode = 'System update';

    switch (evt?.kind) {
      case 'group_participant':
        icon = <Users size={12} className="flex-shrink-0" />;
        text = evt.personJid
          ? `Group membership update — ${evt.personJid}`
          : 'Group membership update';
        break;
      case 'group_self':
        icon = <Users size={12} className="flex-shrink-0" />;
        text = 'Your membership in this group changed';
        break;
      case 'group_photo':
        icon = <ImageIcon size={12} className="flex-shrink-0" />;
        text = 'The group photo was changed';
        break;
      case 'number_change':
        icon = <Phone size={12} className="flex-shrink-0" />;
        text = evt.oldValue && evt.newValue
          ? `Phone number changed: ${evt.oldValue} → ${evt.newValue}`
          : 'A phone number changed';
        break;
      case 'username_change':
        icon = <Users size={12} className="flex-shrink-0" />;
        text = evt.oldValue && evt.newValue
          ? `Username changed: ${evt.oldValue} → ${evt.newValue}`
          : 'A username changed';
        break;
      case 'group_info_change':
        icon = <Users size={12} className="flex-shrink-0" />;
        text = evt.oldValue
          ? `Group info updated (previously: "${evt.oldValue}")`
          : 'Group info was updated';
        break;
      case 'business_notice':
        icon = <Shield size={12} className="flex-shrink-0" />;
        text = 'Business/privacy notice';
        break;
      default:
        text = 'Group or system update — no further details are stored for this event in this backup';
    }

    return (
      <div className="flex justify-center my-2 w-full">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 text-[11px] text-center max-w-xs">
          {icon}
          <span>{text}</span>
        </div>
      </div>
    );
  };

  const renderLocationMessage = () => {
    const info = message.location_info;
    const hasCoords = info && info.latitude != null && info.longitude != null;
    const mapsUrl = hasCoords ? `https://www.google.com/maps?q=${info!.latitude},${info!.longitude}` : null;
    return (
      <div className={`flex items-start gap-2 p-2 rounded-lg ${isSent ? 'bg-green-200/60' : 'bg-gray-100'} mb-1 min-w-[140px]`}>
        <MapPin size={18} className="flex-shrink-0 mt-0.5 text-teal-700" />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-xs uppercase tracking-wide opacity-70 mb-0.5">Location</div>
          {info?.placeName && (
            <div className="text-sm font-medium truncate">{info.placeName}</div>
          )}
          {mapsUrl ? (
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-1 inline-block text-xs text-blue-600 hover:underline"
            >
              View on map
            </a>
          ) : (
            <div className="text-xs opacity-50 italic">No coordinates stored</div>
          )}
        </div>
      </div>
    );
  };

  const renderGenericSystemNotice = () => (
    <div className="flex justify-center my-2 w-full">
      <div className="px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 text-[11px] text-center max-w-xs">
        Group or system update — no further details are stored for this event in this backup
      </div>
    </div>
  );

  if (message.system_kind === 'call') return renderCallMessage();
  if (message.system_kind === 'system_event') return renderSystemEventNotice();
  // Any message that isn't revoked, has no recognized system kind, no
  // media, and no text is something this viewer doesn't decode at all
  // (shouldn't normally happen now that message_type=7 system events are
  // handled above, but kept as a safety net for anything unforeseen).
  // Render it as a centered notice, the same way WhatsApp itself does for
  // these events, instead of a normal chat bubble.
  if (!message.is_revoked
    && message.system_kind !== 'location'
    && message.system_kind !== 'album'
    && !message.has_media
    && !message.text_data) {
    return renderGenericSystemNotice();
  }

  return (
    <div ref={bubbleRef} className={`flex flex-col ${isSent ? 'items-end' : 'items-start'} mb-2 group w-full`}>
      <div
        className={`relative max-w-[85%] md:max-w-[70%] px-2 pt-2 pb-1 rounded-lg shadow-sm text-sm ${
          isSent ? 'bg-[#d9fdd3] rounded-tr-none' : 'bg-white rounded-tl-none'
        }`}
      >
        {isSent ? (
          <span className="absolute -right-[8px] top-0 text-[#d9fdd3]">
            <svg viewBox="0 0 8 13" height="13" width="8" className="fill-current block"><path d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z"></path></svg>
          </span>
        ) : (
          <span className="absolute -left-[8px] top-0 text-white">
            <svg viewBox="0 0 8 13" height="13" width="8" className="fill-current block"><path d="M1.533 3.568L8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path></svg>
          </span>
        )}

        {senderLabel && (
          <div
            className="text-xs font-semibold mb-0.5 px-1 truncate"
            style={{ color: senderColor }}
          >
            {senderLabel}
          </div>
        )}

        {message.is_forwarded && !message.is_revoked && (
          <div className="flex items-center gap-1 text-[11px] text-gray-500 italic mb-0.5 px-1">
            <Forward size={12} className="flex-shrink-0" />
            <span>{message.forwarded_many_times ? 'Forwarded many times' : 'Forwarded'}</span>
          </div>
        )}

        {message.quoted_text && (
          <div className={`mb-1 p-2 rounded text-xs border-l-4 w-full overflow-hidden ${
            isSent ? 'bg-black/5 border-green-600' : 'bg-black/5 border-gray-400'
          }`}>
            <span className={`font-semibold block mb-0.5 ${isSent ? 'text-green-700' : 'text-gray-500'}`}>
              Quoted
            </span>
            <div className="whitespace-pre-wrap break-words line-clamp-4 min-w-0 w-full text-gray-700" style={{ wordBreak: 'break-word' }}>
              {message.quoted_text}
            </div>
          </div>
        )}

        <div className="text-gray-900 px-1 leading-relaxed whitespace-pre-wrap break-words min-w-0 w-full" style={{ wordBreak: 'break-word' }}>
          {message.is_revoked ? (
            <div className="flex items-center text-gray-400 italic py-1 gap-1.5">
              <Ban size={14} className="flex-shrink-0" />
              <span>{isSent ? 'You deleted this message' : 'This message was deleted'}</span>
            </div>
          ) : message.system_kind === 'location' ? (
            renderLocationMessage()
          ) : message.system_kind === 'album' ? (
            <div className="flex items-center text-gray-500 py-1 gap-1.5">
              <ImageIcon size={14} className="flex-shrink-0" />
              <span>
                {(() => {
                  const info = message.album_info;
                  const parts: string[] = [];
                  if (info?.imageCount) parts.push(`${info.imageCount} photo${info.imageCount === 1 ? '' : 's'}`);
                  if (info?.videoCount) parts.push(`${info.videoCount} video${info.videoCount === 1 ? '' : 's'}`);
                  return `Shared an album${parts.length ? ` (${parts.join(', ')})` : ''}`;
                })()}
              </span>
            </div>
          ) : message.has_media ? (
            renderMediaContent()
          ) : message.text_data ? (
            message.text_data
          ) : (
            <div className="flex items-center text-gray-400 italic py-1">
              <File size={14} className="mr-2" />
              <span>System message</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end mt-1 space-x-1 select-none">
          {message.is_edited && !message.is_revoked && (
            <span className="text-[10px] text-gray-400 italic mr-0.5">Edited</span>
          )}
          <time className="text-[10px] text-gray-500 min-w-[45px] text-right">
            {formatTime(message.timestamp)}
          </time>
          {isSent && (
            <span className={message.receipt_status === 'read' ? 'text-blue-500' : 'text-gray-400'}>
              {message.receipt_status === 'delivered' || message.receipt_status === 'read' ? (
                <span className="relative inline-flex items-center" style={{ width: 16 }}>
                  <Check size={12} strokeWidth={3} className="absolute left-0" />
                  <Check size={12} strokeWidth={3} className="absolute left-[4px]" />
                </span>
              ) : (
                <Check size={12} strokeWidth={3} />
              )}
            </span>
          )}
        </div>

        {reactions && reactions.length > 0 && (
          <div className="absolute -bottom-3 right-2 flex bg-white rounded-full shadow px-1 py-0.5 space-x-0.5 border border-gray-100">
            {reactions.map((r) => (
              <span
                key={r.emoji}
                title={r.title}
                className="text-[11px] leading-none flex items-center gap-0.5 px-0.5"
              >
                <span>{r.emoji}</span>
                {r.count > 1 && <span className="text-gray-500 text-[10px]">{r.count}</span>}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
