import React, { useMemo } from 'react';
import { Message, Conversation } from '../types';
import { X, MessageSquare, Image as ImageIcon, Clock, Calendar } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts';
import { ContactMap, normalizePhone } from '../services/contactsService';

interface ChatStatsModalProps {
  conversation: Conversation;
  messages: Message[];
  contactMap: ContactMap;
  isGroup: boolean;
  onClose: () => void;
}

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const ChatStatsModal: React.FC<ChatStatsModalProps> = ({
  conversation,
  messages,
  contactMap,
  isGroup,
  onClose,
}) => {
  const stats = useMemo(() => {
    const real = messages.filter((m) => !m.is_revoked);
    const total = real.length;
    const fromMe = real.filter((m) => m.from_me).length;
    const mediaCount = real.filter((m) => m.has_media).length;

    // Busiest day-of-week and hour-of-day histograms.
    const byDayOfWeek = new Array(7).fill(0);
    const byHour = new Array(24).fill(0);
    const byDateCount = new Map<string, number>();
    const senderCounts = new Map<string, number>();

    for (const m of real) {
      const d = m.timestamp;
      byDayOfWeek[d.getDay()]++;
      byHour[d.getHours()]++;
      const dateKey = d.toISOString().slice(0, 10);
      byDateCount.set(dateKey, (byDateCount.get(dateKey) ?? 0) + 1);

      if (isGroup) {
        const key = m.from_me ? '__me__' : (m.sender_phone || '__unknown__');
        senderCounts.set(key, (senderCounts.get(key) ?? 0) + 1);
      }
    }

    let busiestDate: string | null = null;
    let busiestDateCount = 0;
    for (const [date, count] of byDateCount) {
      if (count > busiestDateCount) { busiestDate = date; busiestDateCount = count; }
    }

    const busiestHour = byHour.indexOf(Math.max(...byHour));
    const busiestDayIdx = byDayOfWeek.indexOf(Math.max(...byDayOfWeek));

    const firstDate = real.length ? real.reduce((a, b) => (a.timestamp < b.timestamp ? a : b)).timestamp : null;
    const lastDate = real.length ? real.reduce((a, b) => (a.timestamp > b.timestamp ? a : b)).timestamp : null;
    const daySpan = firstDate && lastDate
      ? Math.max(1, Math.round((lastDate.getTime() - firstDate.getTime()) / 86400000))
      : 1;

    const topSenders = Array.from(senderCounts.entries())
      .map(([phone, count]) => ({
        phone,
        count,
        label: phone === '__me__' ? 'You' : phone === '__unknown__' ? 'Unknown' : (contactMap[normalizePhone(phone)] || phone),
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    return {
      total,
      fromMe,
      fromThem: total - fromMe,
      mediaCount,
      dayOfWeekChart: DAY_NAMES.map((name, i) => ({ name, count: byDayOfWeek[i] })),
      hourChart: Array.from({ length: 24 }, (_, h) => ({ hour: `${h}`, count: byHour[h] })),
      busiestDate,
      busiestDateCount,
      busiestHour,
      busiestDayName: DAY_NAMES[busiestDayIdx],
      firstDate,
      lastDate,
      avgPerDay: (total / daySpan).toFixed(1),
      topSenders,
    };
  }, [messages, isGroup, contactMap]);

  const chatName = conversation.subject || conversation.contactName || conversation.phone || 'this chat';

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
          <h2 className="font-semibold text-gray-800 truncate">Stats · {chatName}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 flex-shrink-0" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-5">
          {/* Summary tiles */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                <MessageSquare size={13} /> Total messages
              </div>
              <div className="text-xl font-semibold text-gray-800">{stats.total.toLocaleString()}</div>
              {!isGroup && (
                <div className="text-[11px] text-gray-400 mt-0.5">
                  You: {stats.fromMe.toLocaleString()} · Them: {stats.fromThem.toLocaleString()}
                </div>
              )}
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                <ImageIcon size={13} /> Media shared
              </div>
              <div className="text-xl font-semibold text-gray-800">{stats.mediaCount.toLocaleString()}</div>
              <div className="text-[11px] text-gray-400 mt-0.5">~{stats.avgPerDay} msgs/day avg</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                <Calendar size={13} /> Busiest day
              </div>
              <div className="text-sm font-semibold text-gray-800">
                {stats.busiestDate ?? '—'}
              </div>
              <div className="text-[11px] text-gray-400 mt-0.5">{stats.busiestDateCount} messages</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-1.5 text-gray-400 text-xs mb-1">
                <Clock size={13} /> Most active
              </div>
              <div className="text-sm font-semibold text-gray-800">
                {stats.busiestDayName}s, {stats.busiestHour}:00
              </div>
              <div className="text-[11px] text-gray-400 mt-0.5">
                {stats.firstDate?.toLocaleDateString()} – {stats.lastDate?.toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Activity by day of week */}
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Activity by day of week</h3>
            <div style={{ width: '100%', height: 140 }}>
              <ResponsiveContainer>
                <BarChart data={stats.dayOfWeekChart}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip cursor={{ fill: '#f3f4f6' }} />
                  <Bar dataKey="count" fill="#008069" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Activity by hour */}
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Activity by hour of day</h3>
            <div style={{ width: '100%', height: 140 }}>
              <ResponsiveContainer>
                <BarChart data={stats.hourChart}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="hour" tick={{ fontSize: 9 }} interval={2} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip cursor={{ fill: '#f3f4f6' }} labelFormatter={(h) => `${h}:00`} />
                  <Bar dataKey="count" fill="#25D366" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top senders (groups only) */}
          {isGroup && stats.topSenders.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Most active participants</h3>
              <div className="space-y-1.5">
                {stats.topSenders.map((s) => (
                  <div key={s.phone} className="flex items-center gap-2">
                    <span className="text-xs text-gray-600 w-28 truncate flex-shrink-0">{s.label}</span>
                    <div className="flex-1 bg-gray-100 rounded-full h-2.5 overflow-hidden">
                      <div
                        className="bg-[#008069] h-full rounded-full"
                        style={{ width: `${(s.count / stats.topSenders[0].count) * 100}%` }}
                      />
                    </div>
                    <span className="text-[11px] text-gray-400 w-10 text-right flex-shrink-0">{s.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
