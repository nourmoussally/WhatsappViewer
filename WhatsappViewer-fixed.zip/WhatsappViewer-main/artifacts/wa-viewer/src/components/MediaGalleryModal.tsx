import React, { useEffect, useMemo, useState } from 'react';
import { Message } from '../types';
import { X, Image as ImageIcon, Video, Music, FileText, Sticker, Play } from 'lucide-react';
import { STICKER_TYPES, VIDEO_TYPES, AUDIO_TYPES } from './MessageBubble';

interface MediaGalleryModalProps {
  messages: Message[];
  getLocalMediaFile: (message: Message) => File | undefined;
  onClose: () => void;
  onSelectMessage: (messageId: number) => void;
}

type GalleryTab = 'media' | 'documents' | 'audio';

const isVisualMedia = (waType: number | undefined): boolean =>
  waType === 1 || (waType != null && VIDEO_TYPES.has(waType));

interface ThumbProps {
  message: Message;
  file?: File;
}

const GalleryThumb: React.FC<ThumbProps & { onClick: () => void }> = ({ message, file, onClick }) => {
  const [url, setUrl] = useState<string | null>(null);
  const isVideo = message.media_wa_type != null && VIDEO_TYPES.has(message.media_wa_type);
  const isSticker = message.media_wa_type != null && STICKER_TYPES.has(message.media_wa_type);

  useEffect(() => {
    if (!file) { setUrl(null); return; }
    const objUrl = URL.createObjectURL(file);
    setUrl(objUrl);
    return () => URL.revokeObjectURL(objUrl);
  }, [file]);

  return (
    <button
      onClick={onClick}
      className="relative aspect-square bg-gray-100 rounded-md overflow-hidden group focus:outline-none focus:ring-2 focus:ring-green-500"
      title={message.media_name || undefined}
    >
      {url ? (
        isVideo ? (
          <video src={url} className="w-full h-full object-cover" muted preload="metadata" />
        ) : (
          <img
            src={url}
            alt={message.media_caption || message.media_name || 'media'}
            className={`w-full h-full ${isSticker ? 'object-contain p-2' : 'object-cover'}`}
            loading="lazy"
          />
        )
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center text-gray-300 gap-1">
          {isSticker ? <Sticker size={22} /> : isVideo ? <Video size={22} /> : <ImageIcon size={22} />}
          <span className="text-[9px] text-gray-400 px-1 text-center leading-tight">Not found locally</span>
        </div>
      )}
      {isVideo && url && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
          <Play size={22} className="text-white drop-shadow" fill="white" />
        </div>
      )}
    </button>
  );
};

export const MediaGalleryModal: React.FC<MediaGalleryModalProps> = ({
  messages,
  getLocalMediaFile,
  onClose,
  onSelectMessage,
}) => {
  const [tab, setTab] = useState<GalleryTab>('media');

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const { visual, documents, audio } = useMemo(() => {
    const visual: Message[] = [];
    const documents: Message[] = [];
    const audio: Message[] = [];
    for (const m of messages) {
      if (!m.has_media || m.is_revoked) continue;
      const t = m.media_wa_type;
      if (t != null && STICKER_TYPES.has(t)) continue; // stickers excluded from the gallery entirely
      if (isVisualMedia(t)) visual.push(m);
      else if (t != null && AUDIO_TYPES.has(t)) audio.push(m);
      else documents.push(m);
    }
    return { visual, documents, audio };
  }, [messages]);

  const counts = { media: visual.length, documents: documents.length, audio: audio.length };
  const activeList = tab === 'media' ? visual : tab === 'documents' ? documents : audio;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
          <h2 className="font-semibold text-gray-800">Shared media</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700" aria-label="Close gallery">
            <X size={18} />
          </button>
        </div>

        <div className="flex border-b border-gray-200 text-sm">
          {([
            ['media', 'Media', ImageIcon],
            ['documents', 'Documents', FileText],
            ['audio', 'Audio', Music],
          ] as const).map(([key, label, Icon]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 font-medium transition-colors ${
                tab === key ? 'text-[#008069] border-b-2 border-[#008069]' : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <Icon size={14} />
              {label} ({counts[key]})
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-3">
          {activeList.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-10">Nothing here yet.</p>
          ) : tab === 'media' ? (
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-1.5">
              {activeList.map((m) => (
                <GalleryThumb
                  key={m._id}
                  message={m}
                  file={getLocalMediaFile(m)}
                  onClick={() => onSelectMessage(m._id)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-1">
              {activeList.map((m) => {
                const file = getLocalMediaFile(m);
                const Icon = tab === 'audio' ? Music : FileText;
                return (
                  <button
                    key={m._id}
                    onClick={() => onSelectMessage(m._id)}
                    className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-gray-50 text-left"
                  >
                    <div className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center ${
                      file ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-400'
                    }`}>
                      <Icon size={16} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-gray-800 truncate">{m.media_name || 'Untitled'}</p>
                      <p className="text-[11px] text-gray-400">
                        {m.timestamp.toLocaleDateString()}{!file && ' · Not found locally'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
