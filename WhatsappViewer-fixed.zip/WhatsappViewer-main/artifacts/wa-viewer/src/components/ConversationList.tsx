import React, { useState, useMemo } from 'react';
import { Conversation } from '../types';
import { Search, User, Users } from 'lucide-react';

interface ConversationListProps {
  conversations: Conversation[];
  selectedId: number | null;
  onSelect: (conv: Conversation) => void;
}

export const ConversationList: React.FC<ConversationListProps> = ({
  conversations,
  selectedId,
  onSelect,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredConversations = useMemo(() => {
    if (!searchTerm) return conversations;
    const lower = searchTerm.toLowerCase();
    return conversations.filter(
      (c) =>
        (c.subject && c.subject.toLowerCase().includes(lower)) ||
        (c.contactName && c.contactName.toLowerCase().includes(lower)) ||
        (c.jid && c.jid.toLowerCase().includes(lower)) ||
        (c.phone && c.phone.toLowerCase().includes(lower))
    );
  }, [conversations, searchTerm]);

  const isGroup = (conv: Conversation) => !!conv.subject;

  const { privateChats, groupChats } = useMemo(() => {
    const privateChats: Conversation[] = [];
    const groupChats: Conversation[] = [];
    for (const c of filteredConversations) {
      (isGroup(c) ? groupChats : privateChats).push(c);
    }
    return { privateChats, groupChats };
  }, [filteredConversations]);

  const formatDate = (ts: number) => {
    if (!ts) return '';
    const date = new Date(ts);
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  const getAvatarColor = (id: number) => {
    const colors = [
      'bg-emerald-500', 'bg-blue-500', 'bg-purple-500', 'bg-rose-500',
      'bg-amber-500', 'bg-teal-500', 'bg-indigo-500', 'bg-pink-500',
    ];
    return colors[id % colors.length];
  };

  const getInitial = (conv: Conversation) => {
    if (conv.subject) return conv.subject.charAt(0).toUpperCase();
    const phone = conv.phone.replace('+', '');
    return phone.charAt(0) || '#';
  };

  const renderConversationRow = (conv: Conversation) => (
    <div
      key={conv._id}
      onClick={() => onSelect(conv)}
      className={`flex items-center gap-2 px-2.5 py-2 cursor-pointer hover:bg-gray-50 transition-colors border-b border-gray-50 ${
        selectedId === conv._id
          ? 'bg-green-50 hover:bg-green-100 border-l-4 border-l-[#008069]'
          : 'border-l-4 border-l-transparent'
      }`}
    >
      <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white flex-shrink-0 text-xs font-bold ${getAvatarColor(conv._id)}`}>
        {isGroup(conv) ? <Users size={14} /> : getInitial(conv)}
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="text-xs font-semibold text-gray-900 truncate">
          {conv.subject || conv.contactName || conv.phone || 'Number unavailable'}
        </h3>
        {isGroup(conv) ? (
          <p className="text-[11px] text-gray-400 truncate">{conv.jid}</p>
        ) : (
          <p className={`text-[11px] truncate ${conv.phone ? 'text-gray-400 font-mono' : 'text-gray-400 italic'}`}>
            {conv.contactName && conv.phone
              ? conv.phone
              : conv.phone || 'Number unavailable'}
          </p>
        )}
      </div>

      <span className="text-[10px] text-gray-400 flex-shrink-0 whitespace-nowrap self-start mt-0.5">
        {formatDate(conv.timestamp)}
      </span>
    </div>
  );

  const renderColumn = (label: string, icon: React.ReactNode, chats: Conversation[]) => (
    <div className="flex-1 min-w-0 flex flex-col border-r border-gray-100 last:border-r-0">
      <div className="sticky top-0 z-10 flex items-center gap-1.5 bg-gray-50 border-b border-gray-100 px-2.5 py-1.5">
        {icon}
        <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide">{label}</span>
        <span className="text-[10px] text-gray-400 ml-auto">{chats.length}</span>
      </div>
      <div className="flex-1 overflow-y-auto">
        {chats.length === 0 ? (
          <div className="p-4 text-center text-gray-300 text-[11px]">None</div>
        ) : (
          chats.map(renderConversationRow)
        )}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-white border-r border-gray-200 w-full md:w-[440px] lg:w-[560px] xl:w-[640px]">
      <div className="bg-[#008069] px-4 py-3 border-b border-gray-200 flex justify-between items-center">
        <h2 className="font-semibold text-white text-lg">Chats</h2>
        <span className="text-xs text-green-100 bg-white/20 px-2 py-1 rounded-full">
          {conversations.length}
        </span>
      </div>

      <div className="p-3 bg-white border-b border-gray-100">
        <div className="relative">
          <input
            type="text"
            placeholder="Search by name or number..."
            className="w-full pl-9 pr-4 py-2 bg-gray-100 border-transparent focus:bg-white focus:ring-2 focus:ring-green-500 focus:border-transparent rounded-lg text-sm transition-all outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 w-4 h-4" />
        </div>
      </div>

      {filteredConversations.length === 0 ? (
        <div className="flex-1 p-8 text-center text-gray-400 text-sm">
          No chats found matching "{searchTerm}"
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {renderColumn('Private', <User size={12} className="text-gray-400" />, privateChats)}
          {renderColumn('Groups', <Users size={12} className="text-gray-400" />, groupChats)}
        </div>
      )}
    </div>
  );
};
