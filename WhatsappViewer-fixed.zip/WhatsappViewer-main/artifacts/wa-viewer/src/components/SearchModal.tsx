import React, { useEffect, useState } from 'react';
import { Search, X, Loader } from 'lucide-react';
import { SearchResult } from '../services/dbService';

interface SearchModalProps {
  onSearch: (query: string) => SearchResult[];
  onSelectResult: (result: SearchResult) => void;
  onClose: () => void;
  resolveChatLabel: (chatRowId: number) => string;
}

const MIN_QUERY_LENGTH = 2;
const SEARCH_DEBOUNCE_MS = 250;
const SNIPPET_CONTEXT_BEFORE = 30;
const SNIPPET_CONTEXT_AFTER = 40;

const highlightSnippet = (text: string, query: string): React.ReactNode => {
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1 || !query) return text;

  const start = Math.max(0, idx - SNIPPET_CONTEXT_BEFORE);
  const end = Math.min(text.length, idx + query.length + SNIPPET_CONTEXT_AFTER);

  const before = text.slice(start, idx);
  const match = text.slice(idx, idx + query.length);
  const after = text.slice(idx + query.length, end);

  return (
    <>
      {start > 0 && '… '}
      {before}
      <mark className="bg-yellow-200 rounded px-0.5">{match}</mark>
      {after}
      {end < text.length && ' …'}
    </>
  );
};

export const SearchModal: React.FC<SearchModalProps> = ({
  onSearch,
  onSelectResult,
  onClose,
  resolveChatLabel,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < MIN_QUERY_LENGTH) {
      setResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    const timeout = setTimeout(() => {
      try {
        setResults(onSearch(trimmed));
      } finally {
        setSearching(false);
      }
    }, SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const trimmedQuery = query.trim();

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center p-4 pt-16"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 p-3 border-b border-gray-200">
          <Search size={18} className="text-gray-400 flex-shrink-0" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search all conversations…"
            className="flex-1 outline-none text-sm"
          />
          {searching && <Loader size={16} className="animate-spin text-gray-400 flex-shrink-0" />}
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 flex-shrink-0"
            aria-label="Close search"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {trimmedQuery.length > 0 && trimmedQuery.length < MIN_QUERY_LENGTH && (
            <p className="text-xs text-gray-400 p-4">Type at least {MIN_QUERY_LENGTH} characters…</p>
          )}
          {trimmedQuery.length >= MIN_QUERY_LENGTH && !searching && results.length === 0 && (
            <p className="text-sm text-gray-400 p-4 text-center">No matches found.</p>
          )}
          {results.map((r) => (
            <button
              key={r.messageId}
              onClick={() => onSelectResult(r)}
              className="w-full text-left px-4 py-3 border-b border-gray-100 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-semibold text-[#008069] truncate">
                  {resolveChatLabel(r.chatRowId)}
                </span>
                <span className="text-[10px] text-gray-400 flex-shrink-0">
                  {r.timestamp.toLocaleDateString()}
                </span>
              </div>
              <p className="text-sm text-gray-700 break-words">
                {r.fromMe && <span className="text-gray-400">You: </span>}
                {r.matchField === 'caption' && (
                  <span className="text-gray-400 italic">(caption) </span>
                )}
                {highlightSnippet(r.snippet, trimmedQuery)}
              </p>
            </button>
          ))}
          {results.length >= 300 && (
            <p className="text-[11px] text-gray-400 p-3 text-center">
              Showing the first 300 matches. Try a more specific search.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
