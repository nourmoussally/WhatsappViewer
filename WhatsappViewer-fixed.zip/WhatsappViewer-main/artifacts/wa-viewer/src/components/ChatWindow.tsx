import React, { useEffect, useRef, useState } from 'react';
import { Message, Conversation } from '../types';
import { MessageBubble, STICKER_TYPES, VIDEO_TYPES, AUDIO_TYPES } from './MessageBubble';
import { Images, MoreVertical, Phone, MessageSquare, FileDown, Printer, Users, Timer, BarChart3 } from 'lucide-react';
import { downloadConversationHtml, printConversationAsPdf } from '../services/exportService';
import { getGroupMembers, GroupMembersResult } from '../services/dbService';
import { ContactMap, normalizePhone } from '../services/contactsService';
import { MediaGalleryModal } from './MediaGalleryModal';
import { GroupMembersModal } from './GroupMembersModal';
// Lazy-loaded: pulls in the recharts library (~400KB), which most sessions
// never need since stats are opened on demand, not on every chat load.
const ChatStatsModal = React.lazy(() =>
  import('./ChatStatsModal').then((m) => ({ default: m.ChatStatsModal })),
);

// Extensions plausible for each media kind, used to make the "match by
// base filename, ignoring extension" fallback below safe. WhatsApp's
// auto-generated filenames (e.g. PTT-20230115-WA0003) aren't guaranteed
// unique across chats/exports, so an unqualified base-name match can
// silently pick a *different* message's file — a photo or a stale
// duplicate — that happens to share the same base name. That produces a
// blob that looks fine but won't actually decode, which is exactly what
// "sometimes this audio plays, sometimes it doesn't" looks like from the
// outside, even though every message is genuinely Opus/whatever it claims.
const AUDIO_EXTS = ['opus', 'ogg', 'oga', 'mp3', 'm4a', 'aac', 'wav', 'amr'];
const VIDEO_EXTS = ['mp4', '3gp', 'mov', 'webm', 'mkv'];
const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'];

const preferredExtsFor = (waType: number | null | undefined): string[] | undefined => {
  if (waType == null) return undefined;
  if (AUDIO_TYPES.has(waType)) return AUDIO_EXTS;
  if (VIDEO_TYPES.has(waType)) return VIDEO_EXTS;
  if (waType === 1 || STICKER_TYPES.has(waType)) return IMAGE_EXTS;
  return undefined; // documents, contacts, etc. — any extension is plausible
};

interface ChatWindowProps {
  messages: Message[];
  conversation: Conversation | null;
  loading: boolean;
  mediaFiles: Record<string, File>;
  highlightMessageId?: number | null;
  contactMap?: ContactMap;
}

const groupMessagesByDate = (messages: Message[]) => {
  const groups: { [key: string]: Message[] } = {};
  messages.forEach((msg) => {
    const dateStr = msg.timestamp.toLocaleDateString(undefined, {
      year: 'numeric', month: 'long', day: 'numeric',
    });
    if (!groups[dateStr]) groups[dateStr] = [];
    groups[dateStr].push(msg);
  });
  return groups;
};

const normalizeMediaFileName = (value: string): string => {
  const lastPart = value.replace(/\\/g, '/').split('/').pop() || value;
  try {
    return decodeURIComponent(lastPart).toLowerCase();
  } catch {
    return lastPart.toLowerCase();
  }
};

// A small fixed palette (WhatsApp-style) so each group participant gets a
// consistent, distinguishable name color across the whole conversation.
const SENDER_COLORS = [
  '#d1720f', '#0a8a6c', '#5b6fd6', '#c5417b',
  '#3a8fc0', '#8a7215', '#8f4fd6', '#2f9e4f',
];

const senderColorFor = (key: string): string => {
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) {
    hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  }
  return SENDER_COLORS[hash % SENDER_COLORS.length];
};

/** Best-effort display label for who sent a group message: saved contact
 *  name when we have one, otherwise the raw phone number, otherwise a
 *  generic fallback for participants the backup doesn't identify. */
// WhatsApp only ever offers these three disappearing-message durations.
const formatEphemeralDuration = (seconds: number): string => {
  if (seconds >= 7776000) return '90 days';
  if (seconds >= 604800) return '7 days';
  if (seconds >= 86400) return '24 hours';
  return `${Math.round(seconds / 3600)}h`;
};

const getSenderLabel = (message: Message, contactMap: ContactMap): string => {
  if (!message.sender_phone) return 'Unknown participant';
  const name = contactMap[normalizePhone(message.sender_phone)];
  return name || message.sender_phone;
};

interface ReactionSummary { emoji: string; count: number; title: string }

/** Groups a message's raw reactions by emoji into (emoji, count, "who
 *  reacted" tooltip) triples for display — WhatsApp shows one pill per
 *  distinct emoji with a count, not one pill per person. */
const summarizeReactions = (
  message: Message,
  conversation: Conversation | null,
  contactMap: ContactMap,
): ReactionSummary[] => {
  if (!message.reactions || message.reactions.length === 0) return [];
  const isGroup = !!conversation?.subject;
  const reactorLabel = (r: NonNullable<Message['reactions']>[number]): string => {
    if (r.fromMe) return 'You';
    if (isGroup) {
      if (!r.senderPhone) return 'Unknown participant';
      return contactMap[normalizePhone(r.senderPhone)] || r.senderPhone;
    }
    // 1:1 chat — the only possible "other" reactor is the chat contact.
    return conversation?.contactName || conversation?.subject || conversation?.phone || 'Them';
  };

  const byEmoji = new Map<string, string[]>();
  message.reactions.forEach((r) => {
    const names = byEmoji.get(r.emoji) ?? [];
    names.push(reactorLabel(r));
    byEmoji.set(r.emoji, names);
  });
  return Array.from(byEmoji.entries()).map(([emoji, names]) => ({
    emoji,
    count: names.length,
    title: names.join(', '),
  }));
};

export const ChatWindow: React.FC<ChatWindowProps> = ({
  messages,
  conversation,
  loading,
  mediaFiles,
  highlightMessageId,
  contactMap = {},
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const [flashId, setFlashId] = useState<number | null>(null);
  const [manualFiles, setManualFiles] = useState<Record<number, File>>({});
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [showGroupMembers, setShowGroupMembers] = useState(false);
  const [senderFilter, setSenderFilter] = useState<string | null>(null);
  const [showStats, setShowStats] = useState(false);

  const handleManualFileSelect = (messageId: number, file: File) => {
    setManualFiles((prev) => ({ ...prev, [messageId]: file }));
  };

  useEffect(() => {
    setSenderFilter(null);
  }, [conversation?._id]);

  useEffect(() => {
    if (highlightMessageId != null) return; // handled by the highlight effect below
    bottomRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [messages, highlightMessageId]);

  useEffect(() => {
    if (highlightMessageId == null) return;
    // Wait a tick for layout to settle (media loading in a freshly-rendered
    // list can shift heights) before scrolling, and use an instant jump
    // rather than 'smooth' — an animated scroll can get thrown off mid-way
    // by that same layout shifting, landing on the wrong message.
    const raf = requestAnimationFrame(() => {
      const el = messageRefs.current[highlightMessageId];
      if (!el) return;
      el.scrollIntoView({ behavior: 'auto', block: 'center' });
      setFlashId(highlightMessageId);
    });
    const timeout = setTimeout(() => setFlashId(null), 2500);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(timeout);
    };
  }, [highlightMessageId, messages]);

  const mediaCount = messages.filter(m => m.has_media).length;

  const jumpToMessage = (messageId: number) => {
    setShowGallery(false);
    // Wait for the modal's unmount before scrolling so layout has settled.
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const el = messageRefs.current[messageId];
        if (!el) return;
        el.scrollIntoView({ behavior: 'auto', block: 'center' });
        setFlashId(messageId);
        setTimeout(() => setFlashId((cur) => (cur === messageId ? null : cur)), 2500);
      });
    });
  };
  const isGroup = conversation && !!conversation.subject;

  // Distinct senders in this group, with their message counts, for the
  // "filter by participant" dropdown. Not meaningful for 1:1 chats.
  // NOTE: this must run before the early "no conversation selected" return
  // below — React hooks must be called in the same order on every render.
  const groupSenders = React.useMemo(() => {
    if (!isGroup) return [];
    const counts = new Map<string, number>();
    for (const m of messages) {
      const key = m.from_me ? '__me__' : (m.sender_phone || '__unknown__');
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .map(([phone, count]) => ({
        phone,
        count,
        label: phone === '__me__'
          ? 'You'
          : phone === '__unknown__'
            ? 'Unknown participant'
            : (contactMap[normalizePhone(phone)] || phone),
      }))
      .sort((a, b) => b.count - a.count);
  }, [messages, isGroup, contactMap]);

  if (!conversation) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#f0f2f5] border-l border-gray-300 h-full p-8 text-center">
        <div className="bg-gray-200 p-6 rounded-full mb-6">
          <MessageSquare size={48} className="text-gray-400" />
        </div>
        <h2 className="text-2xl font-light text-gray-700 mb-2">WhatsApp Viewer</h2>
        <p className="text-gray-500 max-w-md">
          Select a conversation from the sidebar to view its history.
          Your database is processed locally in your browser.
        </p>
      </div>
    );
  }

  const visibleMessages = senderFilter
    ? messages.filter((m) => (m.from_me ? '__me__' : (m.sender_phone || '__unknown__')) === senderFilter)
    : messages;

  const messageGroups = groupMessagesByDate(visibleMessages);
  const tryMatchName = (rawName: string, preferredExts?: string[]): File | undefined => {
    const fileName = normalizeMediaFileName(rawName);
    if (!fileName) return undefined;
    const exact = mediaFiles[fileName];
    if (exact) return exact;
    const baseName = fileName.replace(/\.[^./\\]+$/, '');
    if (!baseName) return undefined;
    if (preferredExts) {
      // We know what kind of media this message is — only accept a
      // same-base-name match if the candidate file's extension is
      // actually plausible for that kind. Each of these is a precise
      // exact-filename lookup, not the ambiguous "first file with this
      // base name" bucket, so it can't cross-match a different message's
      // file the way the old fallback below could.
      for (const ext of preferredExts) {
        const candidate = mediaFiles[`${baseName}.${ext}`];
        if (candidate) return candidate;
      }
      return undefined;
    }
    // Unknown expected type (documents, contacts, etc.) — any extension
    // is plausible, so fall back to whichever file first claimed this
    // base name.
    return mediaFiles[`base:${baseName}`];
  };
  const getLocalMediaFile = (message: Message): File | undefined => {
    if (manualFiles[message._id]) return manualFiles[message._id];
    const preferredExts = preferredExtsFor(message.media_wa_type);
    if (message.media_name) {
      const match = tryMatchName(message.media_name, preferredExts);
      if (match) return match;
    }
    // The database sometimes stores two different name-like references for
    // the same media (see media-preview-matching notes) — try the other
    // one too before giving up.
    if (message.media_alt_name) {
      const match = tryMatchName(message.media_alt_name, preferredExts);
      if (match) return match;
    }
    return undefined;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#efeae2] relative w-full min-w-0">
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: `url("https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png")`,
          backgroundRepeat: 'repeat'
        }}
      />

      <div className="bg-[#f0f2f5] px-4 py-2.5 flex items-center justify-between border-b border-gray-300 z-10 shadow-sm sticky top-0 w-full">
        <div className="flex items-center min-w-0 flex-1">
          <div className="w-10 h-10 rounded-full bg-[#008069] flex items-center justify-center text-white mr-3 flex-shrink-0">
            <span className="text-sm font-bold">
              {conversation.subject
                ? conversation.subject.charAt(0).toUpperCase()
                : conversation.phone.replace('+', '').charAt(0) || '#'}
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-semibold text-gray-800 text-sm md:text-base flex items-center gap-1.5 min-w-0">
              <span className="truncate min-w-0">
                {conversation.subject || conversation.contactName || conversation.phone || 'Number unavailable'}
              </span>
              {!!conversation.ephemeralExpiration && (
                <span
                  className="inline-flex items-center gap-0.5 text-[10px] font-normal text-gray-500 bg-gray-100 rounded-full px-1.5 py-0.5 flex-shrink-0"
                  title={`Disappearing messages: ${formatEphemeralDuration(conversation.ephemeralExpiration)}`}
                >
                  <Timer size={10} />
                  {formatEphemeralDuration(conversation.ephemeralExpiration)}
                </span>
              )}
            </h2>
            <div className="flex items-center gap-2">
              {!isGroup && (
                <p className="text-xs text-[#008069] font-mono font-semibold truncate">
                  {conversation.contactName && conversation.phone
                    ? `${conversation.contactName} · ${conversation.phone}`
                    : conversation.phone || 'Number unavailable in this backup'}
                </p>
              )}
              {isGroup && (
                <p className="text-xs text-gray-500 truncate">
                  Group
                </p>
              )}
              {messages.length > 0 && (
                <span className="text-xs text-gray-400">
                  · {visibleMessages.length} msgs{mediaCount > 0 ? ` · ${mediaCount} media` : ''}{senderFilter && ' (filtered)'}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3 text-gray-500 flex-shrink-0 relative">
          {isGroup && groupSenders.length > 1 && (
            <select
              value={senderFilter ?? ''}
              onChange={(e) => setSenderFilter(e.target.value || null)}
              className="text-xs border border-gray-200 rounded-md px-1.5 py-1 max-w-[110px] text-gray-600 bg-white"
              title="Filter by participant"
            >
              <option value="">All senders</option>
              {groupSenders.map((s) => (
                <option key={s.phone} value={s.phone}>
                  {s.label} ({s.count})
                </option>
              ))}
            </select>
          )}
          {isGroup && (
            <button
              onClick={() => setShowGroupMembers(true)}
              className="opacity-70 hover:opacity-100"
              aria-label="Group members"
              title="Group members"
            >
              <Users size={18} />
            </button>
          )}
          <button
            onClick={() => setShowGallery(true)}
            className="opacity-70 hover:opacity-100"
            aria-label="Shared media"
            title="Shared media"
          >
            <Images size={18} />
          </button>
          <button onClick={() => setShowExportMenu((v) => !v)} aria-label="More options">
            <MoreVertical size={18} className="opacity-60 hover:opacity-100" />
          </button>
          {showExportMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowExportMenu(false)} />
              <div className="absolute right-0 top-8 z-20 bg-white rounded-lg shadow-lg border border-gray-200 py-1 w-56 text-sm">
                <button
                  onClick={() => { downloadConversationHtml(conversation, messages); setShowExportMenu(false); }}
                  className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center gap-2 text-gray-700"
                >
                  <FileDown size={15} />
                  Export chat as HTML
                </button>
                <button
                  onClick={() => { printConversationAsPdf(conversation, messages); setShowExportMenu(false); }}
                  className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center gap-2 text-gray-700"
                >
                  <Printer size={15} />
                  Print / Save as PDF
                </button>
                <div className="border-t border-gray-100 my-1" />
                <button
                  onClick={() => { setShowStats(true); setShowExportMenu(false); }}
                  className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center gap-2 text-gray-700"
                >
                  <BarChart3 size={15} />
                  Chat statistics
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div
        className="flex-1 overflow-y-auto p-4 z-0 md:px-12 lg:px-24 w-full"
      >
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex justify-center items-center h-full text-gray-400 text-sm">
            No messages found
          </div>
        ) : (
          <>
            {Object.entries(messageGroups).map(([date, msgs]) => (
              <div key={date}>
                <div className="flex justify-center mb-4 sticky top-2 z-10">
                  <span className="bg-white/90 shadow-sm px-3 py-1 rounded-lg text-xs text-gray-600 font-medium backdrop-blur-sm border border-gray-100">
                    {date}
                  </span>
                </div>
                {msgs.map((msg) => (
                  <div
                    key={msg._id}
                    ref={(el) => { messageRefs.current[msg._id] = el; }}
                    className={
                      flashId === msg._id
                        ? 'ring-2 ring-yellow-400 rounded-lg transition-shadow duration-1000'
                        : ''
                    }
                  >
                    <MessageBubble
                      message={msg}
                      localMediaFile={getLocalMediaFile(msg)}
                      onManualFileSelect={handleManualFileSelect}
                      senderLabel={isGroup && !msg.from_me ? getSenderLabel(msg, contactMap) : undefined}
                      senderColor={isGroup && !msg.from_me ? senderColorFor(msg.sender_phone || 'unknown') : undefined}
                      reactions={summarizeReactions(msg, conversation, contactMap)}
                    />
                  </div>
                ))}
              </div>
            ))}
            <div ref={bottomRef} />
          </>
        )}
      </div>

      <div className="bg-[#f0f2f5] p-3 border-t border-gray-300 z-10 flex items-center gap-2 w-full">
        <div className="p-2 text-gray-500 flex-shrink-0">
          <span className="text-xl">😊</span>
        </div>
        <div className="flex-1 bg-white rounded-lg px-4 py-2.5 text-sm text-gray-400 border border-gray-200 italic shadow-sm truncate">
          Read-only archive
        </div>
        <div className="p-2 text-gray-500 flex-shrink-0">
          <span className="text-xl">🎤</span>
        </div>
      </div>

      {showGallery && (
        <MediaGalleryModal
          messages={messages}
          getLocalMediaFile={getLocalMediaFile}
          onClose={() => setShowGallery(false)}
          onSelectMessage={jumpToMessage}
        />
      )}

      {showGroupMembers && conversation && (
        <GroupMembersModal
          data={getGroupMembers(conversation.jid_row_id)}
          contactMap={contactMap}
          onClose={() => setShowGroupMembers(false)}
        />
      )}

      {showStats && conversation && (
        <React.Suspense fallback={
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
            <div className="bg-white rounded-xl px-6 py-4 text-sm text-gray-500">Loading statistics…</div>
          </div>
        }>
          <ChatStatsModal
            conversation={conversation}
            messages={messages}
            contactMap={contactMap}
            isGroup={!!isGroup}
            onClose={() => setShowStats(false)}
          />
        </React.Suspense>
      )}
    </div>
  );
};
