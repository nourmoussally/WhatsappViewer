import React, { useMemo } from 'react';
import { X, Shield, Crown, UserMinus, Users } from 'lucide-react';
import { GroupMembersResult } from '../services/dbService';
import { ContactMap, normalizePhone } from '../services/contactsService';

interface GroupMembersModalProps {
  data: GroupMembersResult;
  contactMap: ContactMap;
  onClose: () => void;
}

const rankLabel = (rank: number): { label: string; icon: React.ReactNode; className: string } | null => {
  if (rank === 2) return { label: 'Owner', icon: <Crown size={12} />, className: 'bg-amber-100 text-amber-700' };
  if (rank === 1) return { label: 'Admin', icon: <Shield size={12} />, className: 'bg-blue-100 text-blue-700' };
  return null;
};

const nameFor = (phone: string, contactMap: ContactMap): string | undefined => {
  const normalized = normalizePhone(phone);
  return normalized ? contactMap[normalized] : undefined;
};

export const GroupMembersModal: React.FC<GroupMembersModalProps> = ({ data, contactMap, onClose }) => {
  const { current, past } = data;

  const sortedCurrent = useMemo(
    () => [...current].sort((a, b) => b.rank - a.rank),
    [current],
  );

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[80vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
          <h2 className="font-semibold text-gray-800 flex items-center gap-1.5">
            <Users size={16} />
            Group members ({current.length})
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {sortedCurrent.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-10">No member data available.</p>
          ) : (
            <div className="divide-y divide-gray-100">
              {sortedCurrent.map((m) => {
                const badge = rankLabel(m.rank);
                const name = nameFor(m.phone, contactMap);
                return (
                  <div key={m.jidRowId} className="flex items-center gap-3 px-4 py-2.5">
                    <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-semibold text-sm flex-shrink-0">
                      {(name || m.phone).replace('+', '').charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-gray-800 truncate">{name || m.phone}</p>
                      {name && <p className="text-[11px] text-gray-400 truncate">{m.phone}</p>}
                    </div>
                    {badge && (
                      <span className={`flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${badge.className}`}>
                        {badge.icon}
                        {badge.label}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {past.length > 0 && (
            <div className="mt-2">
              <div className="px-4 py-2 bg-gray-50 border-y border-gray-100">
                <h3 className="text-xs font-semibold text-gray-500 flex items-center gap-1.5">
                  <UserMinus size={13} />
                  Left / removed ({past.length})
                </h3>
              </div>
              <div className="divide-y divide-gray-100">
                {past.map((p) => {
                  const name = nameFor(p.phone, contactMap);
                  return (
                    <div key={`${p.jidRowId}-${p.timestamp}`} className="flex items-center gap-3 px-4 py-2.5 opacity-70">
                      <div className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 font-semibold text-sm flex-shrink-0">
                        {(name || p.phone).replace('+', '').charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm text-gray-600 truncate">{name || p.phone}</p>
                        <p className="text-[11px] text-gray-400">
                          {p.leftVoluntarily ? 'Left' : 'Removed'}
                          {p.timestamp ? ` · ${new Date(p.timestamp).toLocaleDateString()}` : ''}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
