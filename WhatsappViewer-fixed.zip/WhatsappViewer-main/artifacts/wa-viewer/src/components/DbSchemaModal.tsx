import React, { useState } from 'react';
import { X, ChevronDown, ChevronRight, Database, Table } from 'lucide-react';
import { TableInfo } from '../services/dbService';

interface DbSchemaModalProps {
  schema: TableInfo[];
  onClose: () => void;
}

export const DbSchemaModal: React.FC<DbSchemaModalProps> = ({ schema, onClose }) => {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    message_media: true,
    message: true,
  });

  const toggle = (name: string) => setExpanded(p => ({ ...p, [name]: !p[name] }));

  const highlight = (name: string) =>
    ['file_name', 'file_path', 'media_name', 'original_file_name', 'mime_type',
     'media_caption', 'file_size', 'media_duration', 'duration'].includes(name);

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
          <div className="flex items-center gap-2 text-gray-800 font-semibold">
            <Database size={18} className="text-[#008069]" />
            DB Schema Inspector
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700">
            <X size={22} />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 p-4 space-y-2">
          {schema.map(table => (
            <div key={table.name} className="border border-gray-200 rounded-xl overflow-hidden">
              <button
                onClick={() => toggle(table.name)}
                className={`w-full flex items-center gap-2 px-4 py-2.5 text-left font-medium text-sm transition-colors ${
                  ['message_media', 'message'].includes(table.name)
                    ? 'bg-green-50 text-green-800'
                    : 'bg-gray-50 text-gray-700'
                } hover:bg-green-100`}
              >
                {expanded[table.name] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                <Table size={14} />
                {table.name}
                <span className="ml-auto text-xs text-gray-400 font-normal">
                  {table.columns.length} columns
                </span>
              </button>

              {expanded[table.name] && (
                <div className="px-4 py-3">
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {table.columns.map(col => (
                      <span
                        key={col}
                        className={`px-2 py-0.5 rounded-full text-xs font-mono ${
                          highlight(col)
                            ? 'bg-amber-100 text-amber-800 border border-amber-300 font-semibold'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {col}
                      </span>
                    ))}
                  </div>

                  {table.sampleRows.length > 0 && (
                    <div className="overflow-x-auto">
                      <table className="text-xs w-full border-collapse">
                        <thead>
                          <tr className="bg-gray-50">
                            {table.columns.map(col => (
                              <th
                                key={col}
                                className={`px-2 py-1 text-left border border-gray-200 font-mono whitespace-nowrap ${
                                  highlight(col) ? 'bg-amber-50 text-amber-700' : 'text-gray-500'
                                }`}
                              >
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {table.sampleRows.map((row, i) => (
                            <tr key={i} className="even:bg-gray-50">
                              {row.map((cell, j) => (
                                <td
                                  key={j}
                                  className="px-2 py-1 border border-gray-100 text-gray-700 max-w-[200px] truncate"
                                  title={cell != null ? String(cell) : ''}
                                >
                                  {cell == null ? (
                                    <span className="text-gray-300 italic">null</span>
                                  ) : (
                                    String(cell)
                                  )}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="px-5 py-3 border-t border-gray-100 text-xs text-gray-400">
          🟡 Highlighted columns = media filename / size / caption candidates
        </div>
      </div>
    </div>
  );
};
