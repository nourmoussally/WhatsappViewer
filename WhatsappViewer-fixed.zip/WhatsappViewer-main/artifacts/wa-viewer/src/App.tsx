import React, { useState, useEffect } from 'react';
import { initDatabase, getConversations, getMessages, getMessageRank, getDbSchema, searchMessages, TableInfo, SearchResult } from './services/dbService';
import { ConversationList } from './components/ConversationList';
import { ChatWindow } from './components/ChatWindow';
import { Conversation, Message } from './types';
import { Database, Upload, AlertCircle, Download, Loader, Search } from 'lucide-react';
import { detectEncryptionType, extractKey, decryptDatabase, EncryptionType } from './services/encryptionService';
import { KeyEntryModal } from './components/KeyEntryModal';
import { DbSchemaModal } from './components/DbSchemaModal';
import { SearchModal } from './components/SearchModal';
import { ContactMap, normalizePhone, parseContactsFile } from './services/contactsService';
import {
  isFileSystemAccessSupported,
  saveDirectoryHandle,
  loadSavedDirectoryHandle,
  forgetSavedDirectoryHandle,
  hasReadPermission,
  requestReadPermission,
  collectFilesFromDirectory,
} from './services/folderAccessService';

const App: React.FC = () => {
  const [dbLoaded, setDbLoaded] = useState(false);
  const [showSchema, setShowSchema] = useState(false);
  const [dbSchema, setDbSchema] = useState<TableInfo[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedChat, setSelectedChat] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [contactMap, setContactMap] = useState<ContactMap>({});
  const [contactCount, setContactCount] = useState(0);
  const [mediaFiles, setMediaFiles] = useState<Record<string, File>>({});
  const [mediaFileCount, setMediaFileCount] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loadingMessages, setLoadingMessages] = useState(false);

  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [encryptionType, setEncryptionType] = useState<EncryptionType | null>(null);
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [progressStatus, setProgressStatus] = useState('Decrypting...');

  const [maxChats, setMaxChats] = useState(1000);
  const [maxMessages, setMaxMessages] = useState(5000); // -1 = unlimited (slower for huge chats)

  const [showSearch, setShowSearch] = useState(false);
  const [allChatsForSearch, setAllChatsForSearch] = useState<Conversation[]>([]);
  const [highlightMessageId, setHighlightMessageId] = useState<number | null>(null);

  const [savedFolderName, setSavedFolderName] = useState<string | null>(null);
  const [showFolderReconnectBanner, setShowFolderReconnectBanner] = useState(false);
  const [reconnectingFolder, setReconnectingFolder] = useState(false);
  const supportsFolderPersistence = isFileSystemAccessSupported();

  // On mount: if a media folder was saved from a previous session, try to
  // reuse it. If the browser already has read permission (common in
  // Chrome across the same origin), load the files immediately without
  // any prompt. Otherwise, show a small "reconnect" banner — permission
  // requests must happen from a user gesture (a click), so we can't do
  // this silently.
  useEffect(() => {
    if (!supportsFolderPersistence) return;
    (async () => {
      const handle = await loadSavedDirectoryHandle();
      if (!handle) return;
      setSavedFolderName(handle.name);
      const granted = await hasReadPermission(handle);
      if (granted) {
        const { files, count } = await collectFilesFromDirectory(handle);
        setMediaFiles(files);
        setMediaFileCount(count);
      } else {
        setShowFolderReconnectBanner(true);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleReconnectFolder = async () => {
    setReconnectingFolder(true);
    try {
      const handle = await loadSavedDirectoryHandle();
      if (!handle) return;
      const granted = await requestReadPermission(handle);
      if (granted) {
        const { files, count } = await collectFilesFromDirectory(handle);
        setMediaFiles(files);
        setMediaFileCount(count);
        setShowFolderReconnectBanner(false);
      } else {
        setError('Permission to access the saved media folder was denied.');
      }
    } finally {
      setReconnectingFolder(false);
    }
  };

  const handleForgetFolder = async () => {
    await forgetSavedDirectoryHandle();
    setSavedFolderName(null);
    setShowFolderReconnectBanner(false);
  };

  /** Opens the native folder picker (Chrome/Edge) and remembers the
   *  selection for next time. Falls back to the classic hidden
   *  <input webkitdirectory> element on browsers without support. */
  const triggerMediaFolderPicker = async () => {
    if (!supportsFolderPersistence || !window.showDirectoryPicker) {
      document.getElementById('media-folder-input')?.click();
      return;
    }
    try {
      const handle = await window.showDirectoryPicker({ id: 'wa-media-folder', mode: 'read' });
      const { files, count } = await collectFilesFromDirectory(handle);
      setMediaFiles(files);
      setMediaFileCount(count);
      setSavedFolderName(handle.name);
      setShowFolderReconnectBanner(false);
      await saveDirectoryHandle(handle);
    } catch (err: any) {
      // User cancelled the picker — not an error worth surfacing.
      if (err?.name !== 'AbortError') {
        setError(err?.message || 'Could not access the selected folder.');
      }
    }
  };

  const addContactNames = (chats: Conversation[], map = contactMap): Conversation[] =>
    chats.map((chat) => ({
      ...chat,
      contactName: chat.phone ? map[normalizePhone(chat.phone)] : undefined,
    }));

  const processFile = async (file: File) => {
    setError(null);
    setPendingFile(null);
    setEncryptionType(null);
    setShowKeyModal(false);

    try {
      const buffer = await file.arrayBuffer();
      const detectedType = detectEncryptionType(buffer, file.name);
      if (detectedType) {
        setPendingFile(file);
        setEncryptionType(detectedType);
        setShowKeyModal(true);
        return;
      }
      await initDatabase(buffer);
      setDbLoaded(true);
      loadChats(maxChats);
    } catch (err: any) {
      console.error(err);
      setError('Failed to load database. Please ensure it is a valid msgstore.db file.');
      setDbLoaded(false);
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const handleKeySubmit = async (keyInput: File | string) => {
    if (!pendingFile || !encryptionType) return;
    setIsDecrypting(true);
    setError(null);

    try {
      let keyBuffer: ArrayBuffer;
      if (typeof keyInput === 'string') {
        keyBuffer = new TextEncoder().encode(keyInput).buffer;
      } else {
        keyBuffer = await keyInput.arrayBuffer();
      }
      const { cryptoKey, raw } = await extractKey(keyBuffer);
      const dbBuffer = await pendingFile.arrayBuffer();
      const decryptedBuffer = await decryptDatabase(
        dbBuffer, cryptoKey, encryptionType, raw,
        (status) => setProgressStatus(status)
      );
      setProgressStatus('Initializing Database...');
      await new Promise(r => setTimeout(r, 10));
      await initDatabase(decryptedBuffer);
      setDbLoaded(true);
      loadChats(maxChats);
      setShowKeyModal(false);
      setPendingFile(null);
    } catch (err: any) {
      console.error('Decryption/Load Error:', err);
      setError(err.message || 'Decryption failed. Please check your key file.');
    } finally {
      setIsDecrypting(false);
    }
  };

  const cancelKeyEntry = () => {
    setShowKeyModal(false);
    setPendingFile(null);
    setEncryptionType(null);
  };

  const loadChats = (limit: number) => {
    try {
      const chats = getConversations(limit);
      setConversations(addContactNames(chats));
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleContactsFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    try {
      const result = parseContactsFile(await file.text(), file.name);
      if (result.count === 0) {
        throw new Error('No contacts with a name and phone number were found.');
      }
      setContactMap(result.contacts);
      setContactCount(result.count);
      setConversations((current) => addContactNames(current, result.contacts));
      setSelectedChat((current) => current ? addContactNames([current], result.contacts)[0] : null);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Could not read the contacts file.');
    }
  };

  const handleMediaFolderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // Selecting the WhatsApp Business parent folder gives access to all
    // nested media folders: images, video, audio, documents, stickers, etc.
    const files = Array.from(event.target.files ?? []);
    event.target.value = '';
    if (files.length === 0) {
      setError('No files were found in the selected WhatsApp folder.');
      return;
    }

    const nextFiles: Record<string, File> = {};
    files.forEach((file) => {
      nextFiles[file.name.toLowerCase()] = file;
      const relativePath = (file as File & { webkitRelativePath?: string }).webkitRelativePath;
      if (relativePath) {
        const normalizedPath = relativePath.replace(/\\/g, '/').toLowerCase();
        nextFiles[normalizedPath] = file;
        const relativeName = normalizedPath.split('/').pop();
        if (relativeName && !nextFiles[relativeName]) nextFiles[relativeName] = file;
      }
      // Also index by base name without extension, so a message whose
      // stored media_name has a different (but equivalent) extension than
      // the physical file — e.g. DB says "xxxx.opus" but the file on disk
      // is "xxxx.ogg" — can still be matched.
      const baseName = file.name.toLowerCase().replace(/\.[^./\\]+$/, '');
      if (baseName && !nextFiles[`base:${baseName}`]) {
        nextFiles[`base:${baseName}`] = file;
      }
    });
    setMediaFiles(nextFiles);
    setMediaFileCount(files.length);
    setError(null);
  };

  const openSchema = () => {
    setDbSchema(getDbSchema());
    setShowSchema(true);
  };

  const handleChatSelect = (chat: Conversation, highlightId: number | null = null) => {
    setSelectedChat(chat);
    setLoadingMessages(true);
    setHighlightMessageId(highlightId);
    setTimeout(() => {
      try {
        // getMessages only loads the most recent `limit` messages (-1 means
        // no limit — load everything). If we're jumping to a specific
        // (possibly older) message — e.g. from search — and there IS a
        // limit in effect, make sure the load window is large enough to
        // actually include it, otherwise it silently won't be there to
        // scroll to. Now that the message query's join columns are
        // indexed (see dbService's createPerformanceIndexes), loading the
        // whole conversation in one shot is fast even for large chats.
        let effectiveLimit = maxMessages;
        if (highlightId != null && maxMessages !== -1) {
          const rank = getMessageRank(chat._id, highlightId);
          if (rank != null) {
            effectiveLimit = Math.max(maxMessages, rank + 50);
          }
        }
        const msgs = getMessages(chat._id, effectiveLimit, 0);
        setMessages(msgs);
      } catch (err: any) {
        // Without this, a query failure for one chat's schema edge case
        // throws inside the setTimeout callback, which is unhandled and
        // leaves the chat stuck on its loading spinner forever — this is
        // what "some chats don't open" looks like from the outside.
        console.error('Failed to load messages for chat', chat._id, err);
        setMessages([]);
        setError(err?.message || 'Could not load this conversation. It may use a database layout this viewer does not fully support yet.');
      } finally {
        setLoadingMessages(false);
      }
    }, 10);
  };

  const openSearch = () => {
    // Load a generous, independent list of chats (not limited by the
    // sidebar's "Max Chats" setting) so search results can always resolve
    // a chat label and be opened, even for chats outside that limit.
    const all = addContactNames(getConversations(100000));
    setAllChatsForSearch(all);
    setShowSearch(true);
  };

  const resolveChatLabel = (chatRowId: number): string => {
    const chat = allChatsForSearch.find((c) => c._id === chatRowId)
      ?? conversations.find((c) => c._id === chatRowId);
    if (!chat) return `Chat #${chatRowId}`;
    return chat.subject || chat.contactName || chat.phone || 'Unknown chat';
  };

  const handleSearchResultSelect = (result: SearchResult) => {
    const chat = allChatsForSearch.find((c) => c._id === result.chatRowId)
      ?? conversations.find((c) => c._id === result.chatRowId);
    if (chat) {
      handleChatSelect(chat, result.messageId);
    }
    setShowSearch(false);
  };

  useEffect(() => {
    if (dbLoaded) loadChats(maxChats);
  }, [maxChats, dbLoaded]);

  useEffect(() => {
    if (dbLoaded && selectedChat) handleChatSelect(selectedChat);
  }, [maxMessages]);

  if (!dbLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#008069] to-[#005c4b] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-lg w-full text-center">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-[#008069]">
            <Database size={40} />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-1">WhatsApp DB Viewer</h1>
          <p className="text-gray-500 text-sm mb-2">
            View chats, phone numbers & media details from your <code className="bg-gray-100 px-1 rounded">msgstore.db</code> file.
          </p>
          <p className="text-xs text-gray-400 mb-8">Everything is processed locally in your browser — nothing is uploaded.</p>

          <label className="block w-full cursor-pointer group">
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 hover:border-[#008069] hover:bg-green-50 transition-all flex flex-col items-center">
              <Upload size={32} className="text-gray-400 group-hover:text-[#008069] mb-3" />
              <span className="text-sm font-semibold text-gray-600 group-hover:text-[#008069]">
                Click to select msgstore.db
              </span>
              <span className="text-xs text-gray-400 mt-1">
                Also supports .crypt12, .crypt14, .crypt15
              </span>
            </div>
            <input
              type="file"
              className="hidden"
              accept=".db,application/vnd.sqlite3,.crypt12,.crypt14,.crypt15"
              onChange={handleFileChange}
            />
          </label>

           <label className="mt-4 inline-flex items-center justify-center gap-2 cursor-pointer text-sm text-[#008069] hover:text-green-700 font-medium">
             <Upload size={16} />
             Import contacts (VCF or CSV)
             <input
               type="file"
               className="hidden"
               accept=".vcf,.csv,.txt,text/vcard,text/csv"
               onChange={handleContactsFileChange}
             />
           </label>
           <p className="text-xs text-gray-400 mt-2">
             You can import contacts before or after opening the database.
           </p>
            <button
              type="button"
              onClick={triggerMediaFolderPicker}
              className="mt-3 inline-flex items-center justify-center gap-2 cursor-pointer text-sm text-[#008069] hover:text-green-700 font-medium"
            >
              <Upload size={16} />
              Select WhatsApp Business folder (all media)
            </button>
            <input
              id="media-folder-input"
              type="file"
              className="hidden"
              multiple
              {...({ webkitdirectory: '' } as any)}
              onChange={handleMediaFolderChange}
            />
            <p className="text-xs text-gray-400 mt-2">
              Reads images, video, audio, documents, stickers, and all nested folders.
              {supportsFolderPersistence && ' Your choice is remembered for next time.'}
            </p>

          <div className="mt-6 pt-4 border-t border-gray-100">
            <p className="text-sm text-gray-400 mb-2">Don't have a file? Try the sample:</p>
            <a
              href="https://github.com/trevordixon/whatsapp-msgstore-web-viewer/raw/refs/heads/main/msgstore.db"
              className="inline-flex items-center text-sm text-[#008069] hover:text-green-700 font-medium hover:underline"
              download
            >
              <Download size={16} className="mr-1.5" />
              Download sample msgstore.db
            </a>
          </div>

          {showFolderReconnectBanner && (
            <div className="mt-4 p-3 bg-blue-50 text-blue-800 rounded-xl flex items-center justify-between text-left text-sm border border-blue-200">
              <span>Use previously selected media folder{savedFolderName ? ` "${savedFolderName}"` : ''}?</span>
              <div className="flex gap-2 flex-shrink-0 ml-3">
                <button
                  onClick={handleReconnectFolder}
                  disabled={reconnectingFolder}
                  className="px-2 py-1 bg-blue-600 text-white rounded text-xs font-medium hover:bg-blue-700 disabled:opacity-50"
                >
                  {reconnectingFolder ? 'Connecting…' : 'Use it'}
                </button>
                <button
                  onClick={handleForgetFolder}
                  className="px-2 py-1 text-blue-700 rounded text-xs font-medium hover:bg-blue-100"
                >
                  Forget
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="mt-6 p-4 bg-red-50 text-red-700 rounded-xl flex items-start text-left text-sm border border-red-200">
              <AlertCircle size={20} className="mr-2 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}
        </div>

        {showKeyModal && (
          <KeyEntryModal
            onKeySubmit={handleKeySubmit}
            onCancel={cancelKeyEntry}
            error={isDecrypting ? progressStatus : error}
          />
        )}

        {isDecrypting && !showKeyModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white p-6 rounded-xl flex items-center space-x-4 shadow-xl">
              <Loader className="animate-spin text-[#008069]" />
              <span className="font-medium text-gray-700">{progressStatus}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <div className="bg-[#008069] px-4 py-2 flex items-center justify-between shadow-md z-20">
        <div className="flex items-center space-x-2 text-white font-semibold">
          <Database size={18} />
          <span>WhatsApp DB Viewer</span>
        </div>

        <div className="flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-2">
            <label className="text-green-200">Max Chats:</label>
            <input
              type="number"
              value={maxChats}
              onChange={(e) => setMaxChats(Number(e.target.value))}
              className="w-16 border border-green-700 rounded px-2 py-1 bg-[#006b57] text-white focus:ring-1 focus:ring-white outline-none text-xs"
            />
          </div>
          <div className="flex items-center space-x-2">
            <label className="text-green-200">Max Msgs:</label>
            <input
              type="number"
              min={1}
              placeholder="Unlimited"
              value={maxMessages === -1 ? '' : maxMessages}
              onChange={(e) => {
                const raw = e.target.value;
                const parsed = raw === '' ? -1 : Number(raw);
                setMaxMessages(!raw || Number.isNaN(parsed) || parsed <= 0 ? -1 : parsed);
              }}
              className="w-24 border border-green-700 rounded px-2 py-1 bg-[#006b57] text-white placeholder-green-300 focus:ring-1 focus:ring-white outline-none text-xs"
            />
          </div>
          <button
             onClick={openSearch}
             className="text-green-200 hover:text-white font-medium px-2 py-1 rounded hover:bg-white/20 transition-colors flex items-center gap-1"
           >
             <Search size={14} />
             Search
           </button>
          <button
             onClick={() => document.getElementById('contacts-file-input')?.click()}
             className="text-green-200 hover:text-white font-medium px-2 py-1 rounded hover:bg-white/20 transition-colors"
           >
             Contacts{contactCount > 0 ? ` (${contactCount})` : ''}
           </button>
           <input
             id="contacts-file-input"
             type="file"
             className="hidden"
             accept=".vcf,.csv,.txt,text/vcard,text/csv"
             onChange={handleContactsFileChange}
           />
            <button
              onClick={triggerMediaFolderPicker}
              className="text-green-200 hover:text-white font-medium px-2 py-1 rounded hover:bg-white/20 transition-colors"
              title={savedFolderName ? `Folder: ${savedFolderName}` : undefined}
            >
              Media{mediaFileCount > 0 ? ` (${mediaFileCount})` : ''}
            </button>
            {savedFolderName && (
              <button
                onClick={handleForgetFolder}
                className="text-green-200/70 hover:text-white text-xs px-1 py-1 rounded hover:bg-white/20 transition-colors"
                title="Forget saved media folder"
              >
                ✕
              </button>
            )}
            <input
              id="media-folder-input"
              type="file"
              className="hidden"
              multiple
              {...({ webkitdirectory: '' } as any)}
              onChange={handleMediaFolderChange}
            />
           <button
            onClick={openSchema}
            className="text-green-200 hover:text-white font-medium px-2 py-1 rounded hover:bg-white/20 transition-colors"
          >
            DB Schema
          </button>
          <button
            onClick={() => { setDbLoaded(false); setConversations([]); setSelectedChat(null); setMessages([]); }}
            className="text-red-300 hover:text-white font-medium px-2 py-1 rounded hover:bg-red-600/40 transition-colors"
          >
            Close File
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden relative">
        <div className={`${selectedChat ? 'hidden md:flex' : 'flex'} w-full md:w-auto h-full flex-shrink-0 border-r border-gray-200 bg-white`}>
          <ConversationList
            conversations={conversations}
            selectedId={selectedChat?._id || null}
            onSelect={handleChatSelect}
          />
        </div>
        <div className={`${!selectedChat ? 'hidden md:flex' : 'flex'} flex-1 h-full min-w-0 bg-[#efeae2] relative`}>
          <ChatWindow
            conversation={selectedChat}
            messages={messages}
            loading={loadingMessages}
             mediaFiles={mediaFiles}
             highlightMessageId={highlightMessageId}
             contactMap={contactMap}
          />
          {selectedChat && (
            <button
              onClick={() => setSelectedChat(null)}
              className="md:hidden absolute top-3 left-3 z-50 bg-white/80 p-2 rounded-full shadow-md text-gray-700 backdrop-blur-sm"
            >
              ← Back
            </button>
          )}
        </div>
      </div>

      {showSchema && (
        <DbSchemaModal schema={dbSchema} onClose={() => setShowSchema(false)} />
      )}

      {showSearch && (
        <SearchModal
          onSearch={(q) => searchMessages(q)}
          onSelectResult={handleSearchResultSelect}
          onClose={() => setShowSearch(false)}
          resolveChatLabel={resolveChatLabel}
        />
      )}
    </div>
  );
};

export default App;
